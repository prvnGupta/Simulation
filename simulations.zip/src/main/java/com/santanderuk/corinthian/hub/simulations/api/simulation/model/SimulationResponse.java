package com.santanderuk.corinthian.hub.simulations.api.simulation.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class SimulationResponse extends ModelBase {
    private int simulationId;
    private BigDecimal totalOverpaymentAmount;
    private BigDecimal totalERC;
    private BigDecimal totalPayment;
    private BigDecimal totalAccountSimulationMonthlyPayment;
    private BigDecimal totalInterestBeforeSimulation;
    private BigDecimal totalInterestAfterSimulation;
    private BigDecimal diffInterest;
    private boolean totalInterestChanged;
    private BigDecimal outstandingBalance;
    private BigDecimal totalNextMonthlyPayment;
    private BigDecimal totalSecondMonthlyPayment;
    private BigDecimal totalMonthlyPaymentReduction;
    private int totalTermReduction;
    private List<OutputSimulationLoanData> outputLoanDataList;
}
