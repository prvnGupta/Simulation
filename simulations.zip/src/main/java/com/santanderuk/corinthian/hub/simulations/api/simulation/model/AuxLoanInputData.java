package com.santanderuk.corinthian.hub.simulations.api.simulation.model;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class AuxLoanInputData {
    private String ercCollectionOption;
    private BigDecimal loanInputAmount;
}
