package com.santanderuk.corinthian.hub.simulations.api.simulation;

import com.santanderuk.corinthian.hub.simulations.api.simulation.model.DataResponse;
import com.santanderuk.corinthian.hub.simulations.api.simulation.model.SimulationControllerResponse;
import com.santanderuk.corinthian.hub.simulations.api.simulation.model.SimulationListInput;
import com.santanderuk.corinthian.hub.simulations.api.simulation.services.SimulationService;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfo;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfoCreator;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@Slf4j
public class SimulationController extends BaseController {
    private final SimulationService simulationService;

    @Autowired
    public SimulationController(SimulationService simulationService) {
        this.simulationService = simulationService;
    }

    @ApiOperation(
            value = "Backend aggregation layer to simulate one off overpayments. It now allows multi loan overpayment simulations.",
            nickname = "simulate",
            notes = "This endpoint is used by Corinthian frontend p-sanmf-mortgage-centre application to make one-off overpayments simulations. It receives a list of the simulations to process, uses mortgage-payments System core api and return all the needed information to the frontend."
    )
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK"),
            @ApiResponse(code = 400, message = "Bad Format"),
            @ApiResponse(code = 401, message = "Unauthorised"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 500, message = "Internal Server Error"),
            @ApiResponse(code = 502, message = "Bad gateway"),
            @ApiResponse(code = 503, message = "The service is temporarily unavailable"),
            @ApiResponse(code = 504, message = "Gateway Timeout")})
    @PutMapping(value = "/one-off/{accountNumber}/simulate",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SimulationControllerResponse> simulate(
            @RequestBody SimulationListInput simulationListInput,
            @PathVariable int accountNumber,
            @RequestHeader(name = "Authorization", required = true) String jwtToken) throws GeneralException {

        checkAnmfAccountBelongToCustomer(accountNumber, jwtToken);
        DataResponse data = simulationService.getSimulations(accountNumber, simulationListInput, jwtToken);
        return generateResponse(data);
    }

    private ResponseEntity<SimulationControllerResponse> generateResponse(DataResponse data) {
        ServiceInfo serviceInfo = ServiceInfoCreator.ok();
        SimulationControllerResponse simulationControllerResponse = new SimulationControllerResponse(data, serviceInfo);
        return new ResponseEntity<>(simulationControllerResponse, HttpStatus.OK);
    }
}
