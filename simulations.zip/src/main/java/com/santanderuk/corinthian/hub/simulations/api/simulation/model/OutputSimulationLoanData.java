package com.santanderuk.corinthian.hub.simulations.api.simulation.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class OutputSimulationLoanData extends ModelBase {

    private String loanScheme;
    private int applicationSequenceNumber;
    private BigDecimal loanOverpaymentAmount;
    private BigDecimal loanTotalPaymentAmount;
    private BigDecimal loanERC;
    private BigDecimal currentMonthlyPayment;
    private BigDecimal simulationMonthlyPayment;
    private String currentMaturityDate;
    private String simulationMaturityDate;
    private String newMortgageTerm;
    private String diffMortgageTerm;
    private boolean mortgageTermChanged;
    private BigDecimal diffMonthlyPayment;
    private boolean monthlyPaymentChanged;
    private BigDecimal loanInterestBeforeSimulation;
    private BigDecimal loanInterestAfterSimulation;
    private BigDecimal diffLoanInterestSimulation;
    private boolean loanInterestChanged;
    private BigDecimal firstPaymentAfterOverpayment;
    private BigDecimal secondPaymentAfterOverpayment;

}
