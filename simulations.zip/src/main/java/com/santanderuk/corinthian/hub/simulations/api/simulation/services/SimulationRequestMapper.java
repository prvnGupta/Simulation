package com.santanderuk.corinthian.hub.simulations.api.simulation.services;

import com.santanderuk.corinthian.hub.simulations.api.simulation.model.SimulationInput;
import com.santanderuk.corinthian.hub.simulations.api.simulation.model.SimulationListInput;
import com.santanderuk.corinthian.hub.simulations.api.simulation.model.SimulationLoanDetails;
import com.santanderuk.corinthian.hub.simulations.config.AnmfConfig;
import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.*;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.model.BdpCustomer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Component
@Slf4j
public class SimulationRequestMapper {

    private final AnmfConfig anmfConfig;

    @Autowired
    public SimulationRequestMapper(AnmfConfig anmfConfig) {
        this.anmfConfig = anmfConfig;
    }

    public List<ANMFSimulationRequest> mapInput(int accountNumber, SimulationListInput simulationListInput, BdpCustomer bdpCustomer, String ldapUid) throws GeneralException {
        try {
            List<ANMFSimulationRequest> simulationRequestList = new ArrayList<>(simulationListInput.getSimulationListInput().size());

            for (SimulationInput simulationInput : simulationListInput.getSimulationListInput()) {
                simulationRequestList.add(createAnmfSimulationRequest(accountNumber, simulationInput, bdpCustomer, ldapUid));
            }
            return simulationRequestList;
        } catch (Exception e) {
            log.error("error creating Simulation core request list", e);
            throw new GeneralException("EXC_SIMULATION_MAPPER", "Exception while creating simulation core service request list", e);
        }
    }


    private ANMFSimulationRequest createAnmfSimulationRequest(int accountNumber, SimulationInput simulationInput, BdpCustomer bdpCustomer, String ldapUid) {
        ANMFSimulationRequest anmfSimulationRequest = new ANMFSimulationRequest();

        anmfSimulationRequest.setOverpaymentSimulationRequest(createOperation(accountNumber, simulationInput, bdpCustomer, ldapUid));

        return anmfSimulationRequest;
    }

    private OverpaymentSimulationRequest createOperation(int accountNumber, SimulationInput simulationInput, BdpCustomer bdpCustomer, String ldapUid) {
        OverpaymentSimulationRequest overpaymentSimulationRequest = new OverpaymentSimulationRequest();
        overpaymentSimulationRequest.setInputStruc(createInputStruc(accountNumber, simulationInput, bdpCustomer, ldapUid));
        return overpaymentSimulationRequest;
    }

    private InputStruc createInputStruc(int accountNumber, SimulationInput simulationInput, BdpCustomer bdpCustomer, String ldapUid) {
        InputStruc inputStruc = new InputStruc();
        inputStruc.setISimulationId(simulationInput.getSimulationId());
        inputStruc.setIMortAccNo(accountNumber);
        inputStruc.setIOvpDate(getTodayDateInANMFFormat());
        inputStruc.setITotOvpAmount(calculateTotalOverpaymentAmount(simulationInput));
        inputStruc.setIOriginalSimulationId(0);
        inputStruc.setIErcCollOpt(simulationInput.getErcCollectionOption());
        inputStruc.setIChanTypeCd(anmfConfig.getChannelType());
        inputStruc.setISimVersion(anmfConfig.getSimulationVersion());
        inputStruc.setIBdpType(bdpCustomer.getCustomerType());
        inputStruc.setIBdpNumber(bdpCustomer.getCustomerNumber());
        inputStruc.setIStaffId(ldapUid);
        inputStruc.setICallingAppl(anmfConfig.getCallingApplication());
        inputStruc.setIDistriType("O");
        inputStruc.setIErcAllowImp("");
        inputStruc.setIKfiRefNo("");
        inputStruc.setIUserId(anmfConfig.getUserId());
        inputStruc.setIPaymentData(createPaymentData());
        inputStruc.setILoanData(createLoanData(simulationInput));

        return inputStruc;
    }

    private BigDecimal calculateTotalOverpaymentAmount(SimulationInput simulationInput) {
        BigDecimal totalOverpayment = BigDecimal.ZERO;
        for (SimulationLoanDetails simulationLoanDetails : simulationInput.getSimulationLoanDetails()) {
            totalOverpayment = totalOverpayment.add(simulationLoanDetails.getLoanOverpaymentAmount());
        }
        return totalOverpayment;
    }

    private List<ILoanData> createLoanData(SimulationInput simulationInput) {
        List<ILoanData> iLoanDataList = new ArrayList<>(simulationInput.getSimulationLoanDetails().size());
        for (SimulationLoanDetails simulationLoanDetails : simulationInput.getSimulationLoanDetails()) {
            ILoanData iLoanData = new ILoanData();
            iLoanData.setILoanSch(simulationLoanDetails.getLoanScheme());
            iLoanData.setIApplSeqNo(simulationLoanDetails.getAppSeqNumber());
            iLoanData.setIChangeType(simulationLoanDetails.getLoanChangeType());
            iLoanData.setILnOvpAmount(simulationLoanDetails.getLoanOverpaymentAmount());
            iLoanData.setIErcWaiver("N");
            iLoanData.setIErcWaiverRsn("");
            iLoanDataList.add(iLoanData);
        }
        return iLoanDataList;
    }

    private IPaymentData createPaymentData() {
        IPaymentData iPaymentData = new IPaymentData();
        iPaymentData.setISimPayMeth("");
        return iPaymentData;

    }

    private String getTodayDateInANMFFormat() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDateTime now = LocalDateTime.now();
        return dtf.format(now);
    }

}
