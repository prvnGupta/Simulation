package com.santanderuk.corinthian.hub.simulations.api.simulation.services;

import com.santanderuk.corinthian.hub.simulations.api.simulation.model.AuxLoanInputData;
import com.santanderuk.corinthian.hub.simulations.api.simulation.model.DataResponse;
import com.santanderuk.corinthian.hub.simulations.api.simulation.model.OutputSimulationLoanData;
import com.santanderuk.corinthian.hub.simulations.api.simulation.model.SimulationResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Slf4j
@Component
public class SimulationsResponseMapper {

    public static final String CONST_FORMAT_DDMMYYYY = "dd/MM/yyyy";
    public static final int CONST_ZERO_INT = 0;
    public static final int CONST_TWELVE_INT = 12;
    public static final String CONST_SPACE_YEAR_STRING = " year";
    public static final String CONST_SPACE_YEARS_STRING = " years";
    public static final String CONST_SPACE_MONTH_STRING = " month";
    public static final String CONST_SPACE_MONTHS_STRING = " months";
    public static final String CONST_SPACE_STRING = " ";
    public static final String CONST_COMMA_STRING = ",";

    public SimulationsResponseMapper() {
        // Private constructor
    }


    public DataResponse createResponse(List<ANMFSimulationResponse> anmfSimulationResponseList, List<ANMFSimulationRequest> anmfSimulationRequestList) {
        log.info("anmfToCorinthian method...");
        List<SimulationResponse> simulationResponseList = new ArrayList<>(anmfSimulationResponseList.size());
        for (int i = 0; i < anmfSimulationResponseList.size(); i++) {

            SimulationResponse simulationResponse = translateAnmfToAggregationLayerResponse(anmfSimulationResponseList.get(i), anmfSimulationRequestList.get(i));
            simulationResponseList.add(simulationResponse);
        }
        log.info("anmfToCorinthian finished OK");
        return new DataResponse(simulationResponseList);

    }

    private SimulationResponse translateAnmfToAggregationLayerResponse(ANMFSimulationResponse anmfSimulationResponse, ANMFSimulationRequest anmfSimulationRequest) {
        log.info("translateAnmfToAggregationLayerResponse method...");

        OutputStruc anmfSimulationOutput = anmfSimulationResponse.getOverpaymentSimulationResponse().getOutputStruc();

        SimulationResponse response = new SimulationResponse();
        response.setSimulationId(anmfSimulationOutput.getOSimulationId());
        response.setTotalOverpaymentAmount(anmfSimulationOutput.getOTotOvpAmount());
        response.setTotalERC(anmfSimulationOutput.getOTotErc());
        response.setTotalPayment(anmfSimulationOutput.getOTotPayment());
        response.setTotalAccountSimulationMonthlyPayment(anmfSimulationOutput.getOTotSimMonPay());
        response.setTotalInterestBeforeSimulation(anmfSimulationOutput.getOTotIntBefSim());
        response.setTotalInterestAfterSimulation(anmfSimulationOutput.getOTotIntAftSim());
        response.setDiffInterest(anmfSimulationOutput.getOTotIntSaving());
        response.setTotalInterestChanged(anmfSimulationOutput.getOTotIntSaving().compareTo(BigDecimal.ZERO) > 0);
        response.setOutstandingBalance(anmfSimulationOutput.getOCapBalAftSim());
        response.setTotalNextMonthlyPayment(anmfSimulationOutput.getOTotNextMonPay());
        response.setTotalSecondMonthlyPayment(anmfSimulationOutput.getOTotSecondMonPay());
        response.setTotalMonthlyPaymentReduction(anmfSimulationOutput.getOTotMarSaving());
        response.setTotalTermReduction(anmfSimulationOutput.getOTotTermSaving().intValue());
        response.setOutputLoanDataList(getOutputSimulationLoanDataList(anmfSimulationResponse, anmfSimulationRequest));

        log.debug("ANMF Object was: {}", anmfSimulationResponse);
        log.debug("New Aggregation service object is: {}", response);
        log.info("translateAnmfToAggregationLayerResponse finished OK");

        return response;
    }

    private List<OutputSimulationLoanData> getOutputSimulationLoanDataList(ANMFSimulationResponse anmfSimulationResponse, ANMFSimulationRequest anmfSimulationRequest) {
        List<OutputSimulationLoanData> outputSimulationLoanDataList = new ArrayList<>(anmfSimulationResponse.getOverpaymentSimulationResponse().getOutputStruc().getOLoanData().size());
        for (OLoanData oLoanData : anmfSimulationResponse.getOverpaymentSimulationResponse().getOutputStruc().getOLoanData()) {
            AuxLoanInputData auxLoanInputData = matchInputLoan(oLoanData, anmfSimulationRequest);
            OutputSimulationLoanData calOutputSimulationLoanData = calculateOLoanDataSimulation(oLoanData, auxLoanInputData);
            outputSimulationLoanDataList.add(calOutputSimulationLoanData);
        }
        return outputSimulationLoanDataList;
    }

    private AuxLoanInputData matchInputLoan(OLoanData oLoanData, ANMFSimulationRequest anmfSimulationRequest) {
        AuxLoanInputData auxLoanInputData = new AuxLoanInputData();
        auxLoanInputData.setErcCollectionOption(anmfSimulationRequest.getOverpaymentSimulationRequest().getInputStruc().getIErcCollOpt());
        for (ILoanData iLoanData : anmfSimulationRequest.getOverpaymentSimulationRequest().getInputStruc().getILoanData()) {
            if (isSameLoan(oLoanData, iLoanData)) {
                auxLoanInputData.setLoanInputAmount(iLoanData.getILnOvpAmount());
            }
        }
        return auxLoanInputData;
    }

    private boolean isSameLoan(OLoanData oLoanData, ILoanData iLoanData) {
        return iLoanData.getILoanSch().equalsIgnoreCase(oLoanData.getOLoanSch()) && iLoanData.getIApplSeqNo() == oLoanData.getOApplSeqNo();
    }

    private OutputSimulationLoanData calculateOLoanDataSimulation(OLoanData oLoanData, AuxLoanInputData auxLoanInputData) {
        String diffMortgageTerm = "0 years, 0 months";
        diffMortgageTerm = calculateDiffTerm(oLoanData.getOLnCurrMatDt(), oLoanData.getOLnSimMatDt());
        OutputSimulationLoanData outputSimulationLoanData = new OutputSimulationLoanData();
        outputSimulationLoanData.setLoanScheme(oLoanData.getOLoanSch());
        outputSimulationLoanData.setApplicationSequenceNumber(oLoanData.getOApplSeqNo());
        outputSimulationLoanData.setLoanOverpaymentAmount(auxLoanInputData.getErcCollectionOption().equalsIgnoreCase("I") ? auxLoanInputData.getLoanInputAmount().subtract(oLoanData.getOLnErc()) : auxLoanInputData.getLoanInputAmount());
        outputSimulationLoanData.setLoanTotalPaymentAmount(auxLoanInputData.getErcCollectionOption().equalsIgnoreCase("I") ? auxLoanInputData.getLoanInputAmount() : auxLoanInputData.getLoanInputAmount().add(oLoanData.getOLnErc()));
        outputSimulationLoanData.setLoanERC(oLoanData.getOLnErc());
        outputSimulationLoanData.setCurrentMonthlyPayment(oLoanData.getOLnCurrMonPay());
        outputSimulationLoanData.setSimulationMonthlyPayment(oLoanData.getOLnSimMonPay());
        outputSimulationLoanData.setCurrentMaturityDate(oLoanData.getOLnCurrMatDt());
        outputSimulationLoanData.setSimulationMaturityDate(oLoanData.getOLnSimMatDt());
        outputSimulationLoanData.setNewMortgageTerm(calculateTermRemaining(oLoanData.getOLnSimMatDt()));
        outputSimulationLoanData.setDiffMortgageTerm(diffMortgageTerm);
        outputSimulationLoanData.setMortgageTermChanged(oLoanData.getOTermSaving().intValue() > 0);
        outputSimulationLoanData.setDiffMonthlyPayment(oLoanData.getOMarSaving());
        outputSimulationLoanData.setMonthlyPaymentChanged(oLoanData.getOMarSaving().compareTo(BigDecimal.ZERO) > 0);
        outputSimulationLoanData.setLoanInterestBeforeSimulation(oLoanData.getOLnIntBefSim());
        outputSimulationLoanData.setLoanInterestAfterSimulation(oLoanData.getOLnIntAftSim());
        outputSimulationLoanData.setDiffLoanInterestSimulation(oLoanData.getOIntSaving());
        outputSimulationLoanData.setLoanInterestChanged(oLoanData.getOIntSaving().compareTo(BigDecimal.ZERO) > 0);
        outputSimulationLoanData.setFirstPaymentAfterOverpayment(oLoanData.getONextMonPay());
        outputSimulationLoanData.setSecondPaymentAfterOverpayment(oLoanData.getOSecondMonPay());
        return outputSimulationLoanData;
    }

    private String calculateTermRemaining(String simMaturityDate) {

        log.debug("CalculateTermRemaining for simMaturityDate: {}", simMaturityDate);
        SimpleDateFormat sdfSimMatDate = new SimpleDateFormat(CONST_FORMAT_DDMMYYYY);
        sdfSimMatDate.setLenient(false);
        int monthsTillMaturity;
        try {
            Date maturityDate = sdfSimMatDate.parse(simMaturityDate);
            SimpleDateFormat todaySfd = new SimpleDateFormat(CONST_FORMAT_DDMMYYYY);
            Date todayDate;
            todayDate = todaySfd.parse(todaySfd.format(new Date()));
            monthsTillMaturity = getDiffDatesNewMortgageTerm(todayDate, maturityDate);
        } catch (ParseException e) {
            log.error("Error on calculateTermRemaining method. simMaturityDate: {}", simMaturityDate, e);
            return "";
        }

        int years = monthsTillMaturity / CONST_TWELVE_INT;
        int months = monthsTillMaturity - (years * CONST_TWELVE_INT);

        String yearDescription =
                years == 1 ?
                        String.valueOf(years).concat(CONST_SPACE_YEAR_STRING)
                        :
                        String.valueOf(years).concat(CONST_SPACE_YEARS_STRING);

        String monthDescription =
                months == 1 ?
                        String.valueOf(months).concat(CONST_SPACE_MONTH_STRING)
                        :
                        String.valueOf(months).concat(CONST_SPACE_MONTHS_STRING);
        log.debug("CalculateTermRemaining finish ok");
        return yearDescription.concat(CONST_SPACE_STRING).concat(monthDescription);
    }

    private String calculateDiffTerm(String currMaturityDate, String simMaturityDate) {
        log.debug("calculateDiffTerm for currentMaturityDate: {} SimulationMaturityDate: {}", currMaturityDate, simMaturityDate);

        SimpleDateFormat sdfSimMatDate = new SimpleDateFormat(CONST_FORMAT_DDMMYYYY);
        sdfSimMatDate.setLenient(false);

        SimpleDateFormat sdfCurrMatDate = new SimpleDateFormat(CONST_FORMAT_DDMMYYYY);
        sdfCurrMatDate.setLenient(false);

        int monthsTillMaturity = CONST_ZERO_INT;
        try {
            Date simulationMaturityDate = sdfSimMatDate.parse(simMaturityDate);
            Date currentMaturityDate = sdfCurrMatDate.parse(currMaturityDate);
            monthsTillMaturity = getDiffDatesDiffTerm(simulationMaturityDate, currentMaturityDate);
        } catch (ParseException e) {
            log.error("Error on calculateDiffTerm method. currentMaturityDate: {} SimulationMaturityDate: {}", currMaturityDate, simMaturityDate, e);
        }

        int years = monthsTillMaturity / CONST_TWELVE_INT;
        int months = monthsTillMaturity - (years * CONST_TWELVE_INT);

        String yearDescription =
                years == 1 ?
                        String.valueOf(years).concat(CONST_SPACE_YEAR_STRING)
                        :
                        String.valueOf(years).concat(CONST_SPACE_YEARS_STRING);

        String monthDescription =
                months == 1 ?
                        String.valueOf(months).concat(CONST_SPACE_MONTH_STRING)
                        :
                        String.valueOf(months).concat(CONST_SPACE_MONTHS_STRING);

        log.debug("calculateDiffTerm finish ok");
        return yearDescription.concat(CONST_COMMA_STRING).concat(CONST_SPACE_STRING).concat(monthDescription);
    }

    private int getDiffDatesDiffTerm(final Date s1, final Date s2) {
        final Calendar d1 = Calendar.getInstance();
        d1.setTime(s1);
        final Calendar d2 = Calendar.getInstance();
        d2.setTime(s2);
        int diff;
        if (d2.get(Calendar.DAY_OF_MONTH) < d1.get(Calendar.DAY_OF_MONTH)) {
            diff = (d2.get(Calendar.YEAR) - d1.get(Calendar.YEAR)) * 12 + d2.get(Calendar.MONTH) - d1.get(Calendar.MONTH) - 1;
        } else {
            diff = (d2.get(Calendar.YEAR) - d1.get(Calendar.YEAR)) * 12 + d2.get(Calendar.MONTH) - d1.get(Calendar.MONTH);
        }
        return diff;
    }

    private int getDiffDatesNewMortgageTerm(final Date s1, final Date s2) {
        final Calendar d1 = Calendar.getInstance();
        d1.setTime(s1);
        final Calendar d2 = Calendar.getInstance();
        d2.setTime(s2);
        int diff;
        if (d2.get(Calendar.DAY_OF_MONTH) > d1.get(Calendar.DAY_OF_MONTH)) {
            diff = (d2.get(Calendar.YEAR) - d1.get(Calendar.YEAR)) * 12 + d2.get(Calendar.MONTH) - d1.get(Calendar.MONTH) + 1;
        } else {
            diff = (d2.get(Calendar.YEAR) - d1.get(Calendar.YEAR)) * 12 + d2.get(Calendar.MONTH) - d1.get(Calendar.MONTH);
        }
        return diff;
    }

}
