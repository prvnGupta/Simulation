package com.santanderuk.corinthian.hub.simulations.api.simulation.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SimulationInput extends ModelBase {
    private int simulationId;
    private String ercCollectionOption;
    private List<SimulationLoanDetails> simulationLoanDetails;
}
