package com.santanderuk.corinthian.hub.simulations.config;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import java.math.BigDecimal;

@Configuration
@Getter
public class AnmfConfig {

    @Value("${anmf.services.simulation}")
    private String simulationUrl;

    @Value("${simulation.userid}")
    private String userId;

    @Value("${validations.operativesecurity}")
    private boolean operativeSecurity;

    @Value("${validations.minsimulationamount}")
    private BigDecimal minSimulationAmount;

    @Value("${anmf.services.customerservice}")
    private String anmfCustomerServiceUrl;

    @Value("${anmf.services.account-service}")
    private String anmfAccountServiceUrl;

    @Value("${simulation.channel-type}")
    private String channelType;

    @Value("${simulation.calling-application}")
    private String callingApplication;

    @Value("${simulation.version}")
    private int simulationVersion;
}
