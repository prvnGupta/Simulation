package com.santanderuk.corinthian.hub.simulations.api.simulation.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SimulationLoanDetails extends ModelBase {
    private String loanScheme;
    private int appSeqNumber;
    private BigDecimal loanOverpaymentAmount;
    private String loanChangeType;
}
