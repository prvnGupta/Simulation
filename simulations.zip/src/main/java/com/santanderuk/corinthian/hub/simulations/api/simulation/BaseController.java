package com.santanderuk.corinthian.hub.simulations.api.simulation;

import com.santanderuk.corinthian.hub.simulations.api.simulation.model.SimulationERCErrorResponse;
import com.santanderuk.corinthian.hub.simulations.config.AnmfConfig;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.HeartBeatClient;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.exceptions.OperativeSecurityException;
import com.santanderuk.corinthian.services.commons.operativesecurity.AnmfBelongToCustomerService;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfoCreator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;

@Slf4j
public class BaseController {

    public static final String ERROR_SECURITY_KO_CODE = "SECURITY_KO";
    public static final String ERROR_SECURITY_KO_MESSAGE = "Mortgage does not belong to customer";
    public static final String LOGGING_ERROR_SECURITY_KO = "Security KO. Mortgage does not belong to customer";

    @Autowired
    private AnmfConfig anmfConfig;
    @Autowired
    private AnmfBelongToCustomerService anmfBelongToCustomerService;
    @Autowired
    private HeartBeatClient heartBeatClient;


    @ExceptionHandler(OperativeSecurityException.class)
    public ResponseEntity<SimulationERCErrorResponse> handleOperativeSecurityException(final OperativeSecurityException operativeSecurityException) {
        final var wrapper = new SimulationERCErrorResponse();
        var info = ServiceInfoCreator.exception(operativeSecurityException);
        wrapper.setInfo(info);
        return new ResponseEntity<>(wrapper, HttpStatus.UNAUTHORIZED);
    }

    @ExceptionHandler(GeneralException.class)
    public ResponseEntity<SimulationERCErrorResponse> handleGeneralException(final GeneralException generalException) {
        final var wrapper = new SimulationERCErrorResponse();
        var info = ServiceInfoCreator.exception(generalException);
        wrapper.setInfo(info);
        return new ResponseEntity<>(wrapper, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    public void checkAnmfAccountBelongToCustomer(final int accountNumber, final String jwtToken) throws OperativeSecurityException {

        try {
            boolean operativeSecurityActive = anmfConfig.isOperativeSecurity();

            log.info("check operative security: {}", operativeSecurityActive);
            if (operativeSecurityActive) {
                log.info("Check if anmf account belong to customer in jwtToken");
                log.debug("JWT Token is : {}", jwtToken.replaceAll("[\r\n]", ""));

                var anmfBelongsToCustomer = anmfBelongToCustomerService.anmfBelongsToCustomer(accountNumber, jwtToken, anmfConfig.getAnmfCustomerServiceUrl(), heartBeatClient.fetchCurrentRegion());

                if (!anmfBelongsToCustomer) {
                    log.error(LOGGING_ERROR_SECURITY_KO);
                    throw new OperativeSecurityException(ERROR_SECURITY_KO_CODE, ERROR_SECURITY_KO_MESSAGE);
                }
            }
        } catch (Exception e) {
            throw new OperativeSecurityException(ERROR_SECURITY_KO_CODE, ERROR_SECURITY_KO_MESSAGE);
        }
    }

}
