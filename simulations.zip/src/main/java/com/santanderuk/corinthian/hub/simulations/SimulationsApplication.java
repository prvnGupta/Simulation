package com.santanderuk.corinthian.hub.simulations;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Created by C02229411 on 08/03/2017. PROJECT: simulations
 */
@SpringBootApplication
public class SimulationsApplication {
    public static void main(String[] args) {
        SpringApplication.run(SimulationsApplication.class, args);
    }
}

