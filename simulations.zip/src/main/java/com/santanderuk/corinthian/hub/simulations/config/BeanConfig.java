package com.santanderuk.corinthian.hub.simulations.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.santanderuk.corinthian.services.commons.anmfclient.AnmfCoreClient;
import com.santanderuk.corinthian.services.commons.anmfclient.SimulationClient;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.HeartBeatClient;
import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import com.santanderuk.corinthian.services.commons.operativesecurity.AnmfBelongToCustomerService;
import com.santanderuk.corinthian.services.commons.validations.Validations;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class BeanConfig {

    @Bean
    public AnmfBelongToCustomerService anmfBelongToCustomerService() {
        return new AnmfBelongToCustomerService();
    }

    @Bean
    public SimulationClient simulationClient() {
        return new SimulationClient(restTemplate(), apiManagerConfig());
    }

    @Bean
    public HeartBeatClient heartBeatClient() {
        return new HeartBeatClient();
    }

    @Bean
    public AnmfCoreClient anmfCoreClient() {
        return new AnmfCoreClient(objectMapper(), restTemplate(), apiManagerConfig());
    }

    @Bean
    public ObjectMapper objectMapper() {
        return new ObjectMapper();
    }

    @Bean
    public ApiManagerConfig apiManagerConfig() {
        return new ApiManagerConfig();
    }

    @Bean
    RestTemplate restTemplate() {
        return new RestTemplate();
    }

    @Bean
    public Validations validations() {
        return new Validations();
    }

}
