package com.santanderuk.corinthian.hub.simulations.api.simulation.model;

import com.santanderuk.corinthian.services.commons.model.ModelBase;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfo;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SimulationERCErrorResponse extends ModelBase {
    private DataResponse dataResponse;
    private ServiceInfo info;

}
