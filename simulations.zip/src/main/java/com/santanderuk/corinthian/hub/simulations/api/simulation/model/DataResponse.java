package com.santanderuk.corinthian.hub.simulations.api.simulation.model;

import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DataResponse extends ModelBase {
    private List<SimulationResponse> simulationResponseList;
}
