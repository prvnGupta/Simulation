package com.santanderuk.corinthian.hub.simulations.api.simulation.services;

import com.santanderuk.corinthian.hub.simulations.api.simulation.model.DataResponse;
import com.santanderuk.corinthian.hub.simulations.api.simulation.model.SimulationListInput;
import com.santanderuk.corinthian.hub.simulations.config.AnmfConfig;
import com.santanderuk.corinthian.services.commons.anmfclient.SimulationClient;
import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.ANMFSimulationRequest;
import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.ANMFSimulationResponse;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.HeartBeatClient;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.model.BdpCustomer;
import com.santanderuk.corinthian.services.commons.utilities.JwtUtilities;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class SimulationService {
    private final SimulationRequestMapper simulationRequestMapper;
    private final AnmfConfig anmfConfig;
    private final HeartBeatClient heartBeatClient;
    private final SimulationClient simulationClient;
    private final SimulationsResponseMapper simulationsResponseMapper;

    @Autowired
    public SimulationService(SimulationRequestMapper simulationRequestMapper, AnmfConfig anmfConfig, HeartBeatClient heartBeatClient, SimulationClient simulationClient, SimulationsResponseMapper simulationsResponseMapper) {
        this.simulationRequestMapper = simulationRequestMapper;
        this.anmfConfig = anmfConfig;
        this.heartBeatClient = heartBeatClient;
        this.simulationClient = simulationClient;
        this.simulationsResponseMapper = simulationsResponseMapper;
    }

    public DataResponse getSimulations(int accountNumber, SimulationListInput simulationListInput, String jwtToken) throws GeneralException {
        BdpCustomer bdpCustomer = JwtUtilities.getBdpCustomerFromJWT(jwtToken);
        String ldapUid = JwtUtilities.getLdapUidFromJWT(jwtToken);

        List<ANMFSimulationRequest> anmfSimulationRequestList = simulationRequestMapper.mapInput(accountNumber, simulationListInput, bdpCustomer, ldapUid);

        List<ANMFSimulationResponse> anmfSimulationResponseList = simulate(anmfSimulationRequestList);

        return simulationsResponseMapper.createResponse(anmfSimulationResponseList, anmfSimulationRequestList);
    }

    public List<ANMFSimulationResponse> simulate(List<ANMFSimulationRequest> simulationList) throws GeneralException {
        String anmfSimulationEndpoint = anmfConfig.getSimulationUrl();


        int originalSimulationId = simulationList.get(0).getOverpaymentSimulationRequest().getInputStruc().getISimulationId();

        List<ANMFSimulationResponse> anmfSimulationResponseList = new ArrayList<>(simulationList.size());

        for (int i = 0; i < simulationList.size(); i++) {
            ANMFSimulationRequest anmfSimulationRequest = simulationList.get(i);

            anmfSimulationRequest.getOverpaymentSimulationRequest().getInputStruc().setISimulationId(originalSimulationId);
            log.info("Calling ANMF Simulation Service. Index: {}", i + 1);
            log.debug("Calling endpoint {} with object {}", anmfSimulationEndpoint, anmfSimulationRequest);
            ANMFSimulationResponse anmfSimulationResponse = simulationClient.simulate(
                    anmfSimulationEndpoint, anmfSimulationRequest, heartBeatClient.fetchCurrentRegion());
            anmfSimulationResponseList.add(anmfSimulationResponse);
            if (i == 0) {
                originalSimulationId = anmfSimulationResponse.getOverpaymentSimulationResponse().getOutputStruc().getOSimulationId();
            }
            log.debug("ANMFSimulation.connect response: {}", anmfSimulationResponse);
            log.info("ANMF simulation service finish OK, index: {}", i + 1);
        }

        return anmfSimulationResponseList;
    }

}
