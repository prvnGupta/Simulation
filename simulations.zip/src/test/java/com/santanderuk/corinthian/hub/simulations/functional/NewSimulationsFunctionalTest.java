package com.santanderuk.corinthian.hub.simulations.functional;

import com.jayway.restassured.response.Header;
import com.jayway.restassured.response.Headers;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

import java.math.BigDecimal;

import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.not;

@ActiveProfiles("test")
public class NewSimulationsFunctionalTest extends FunctionalTest {

    Headers headers;

    String simulationEndpoint;

    @BeforeEach
    public void setup() {
        simulationEndpoint = String.format("http://localhost:%s/simulations/one-off/30000665/simulate", serverPort);

        Header authorization = new Header("authorization", jwtAuth);
        Header content = new Header("Content-Type", "application/json");
        Header accept = new Header("Accept", "application/json");

        headers = new Headers(authorization, content, accept);
        stubGetAnmfCustomerInfo();
    }

    @Test
    public void testHappyPathIncludeOrAddTheChargeSimulationEndpoint() {

        stubGetRegionHeartbeat();
        stubAnmfIncludeCharge();
        stubAnmfAddCharge();
        stubAccountServiceOk();

        given().
                headers(headers).
                body(readFileContents("simulation/valid-simulation-request-include-or-add.json")).
                when().
                put(simulationEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "dataResponse.simulationResponseList[0].simulationId", equalTo(6974484),
                        "dataResponse.simulationResponseList[0].totalOverpaymentAmount", equalTo(new BigDecimal("4992.07")),
                        "dataResponse.simulationResponseList[0].totalERC", equalTo(new BigDecimal("7.93")),
                        "dataResponse.simulationResponseList[0].totalPayment", equalTo(5000),
                        "dataResponse.simulationResponseList[0].totalAccountSimulationMonthlyPayment", equalTo(new BigDecimal("190.79")),
                        "dataResponse.simulationResponseList[0].totalInterestBeforeSimulation", equalTo(new BigDecimal("11754.02")),
                        "dataResponse.simulationResponseList[0].totalInterestAfterSimulation", equalTo(new BigDecimal("10343.14")),
                        "dataResponse.simulationResponseList[0].diffInterest", equalTo(new BigDecimal("1410.88")),
                        "dataResponse.simulationResponseList[0].totalInterestChanged", equalTo(true),
                        "dataResponse.simulationResponseList[0].outstandingBalance", equalTo(new BigDecimal("36410.89")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanScheme", equalTo("3R"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].applicationSequenceNumber", equalTo(2),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanERC", equalTo(new BigDecimal("7.93")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].currentMonthlyPayment", equalTo(new BigDecimal("216.95")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].simulationMonthlyPayment", equalTo(new BigDecimal("190.79")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].currentMaturityDate", equalTo("07/10/2042"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].simulationMaturityDate", equalTo("07/10/2042"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].newMortgageTerm", not(null),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].newMortgageTerm", not(equalTo("")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].diffMortgageTerm", equalTo("0 years, 0 months"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].monthlyPaymentChanged", equalTo(true),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].diffMonthlyPayment", equalTo(new BigDecimal("0.94")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanInterestChanged", equalTo(true),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanInterestBeforeSimulation", equalTo(new BigDecimal("11754.02")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanInterestAfterSimulation", equalTo(new BigDecimal("10343.14")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].diffLoanInterestSimulation", equalTo(new BigDecimal("83.87")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].firstPaymentAfterOverpayment", equalTo(new BigDecimal("7889.52")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].secondPaymentAfterOverpayment", equalTo(new BigDecimal("7886.58")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].mortgageTermChanged", equalTo(false),
                        "dataResponse.simulationResponseList[1].simulationId", equalTo(6974484),
                        "dataResponse.simulationResponseList[1].totalOverpaymentAmount", equalTo(5000),
                        "dataResponse.simulationResponseList[1].totalERC", equalTo(new BigDecimal("8.01")),
                        "dataResponse.simulationResponseList[1].totalPayment", equalTo(new BigDecimal("5008.01")),
                        "dataResponse.simulationResponseList[1].totalAccountSimulationMonthlyPayment", equalTo(new BigDecimal("190.75")),
                        "dataResponse.simulationResponseList[1].totalInterestBeforeSimulation", equalTo(new BigDecimal("11754.02")),
                        "dataResponse.simulationResponseList[1].totalInterestAfterSimulation", equalTo(new BigDecimal("10340.79")),
                        "dataResponse.simulationResponseList[1].diffInterest", equalTo(new BigDecimal("1410.88")),
                        "dataResponse.simulationResponseList[1].totalInterestChanged", equalTo(true),
                        "dataResponse.simulationResponseList[1].outstandingBalance", equalTo(new BigDecimal("36402.96")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanScheme", equalTo("3R"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].applicationSequenceNumber", equalTo(2),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanERC", equalTo(new BigDecimal("8.01")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].currentMonthlyPayment", equalTo(new BigDecimal("216.95")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].simulationMonthlyPayment", equalTo(new BigDecimal("190.75")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].currentMaturityDate", equalTo("07/10/2042"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].simulationMaturityDate", equalTo("07/10/2042"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].newMortgageTerm", not(null),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].newMortgageTerm", not(equalTo("")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].diffMortgageTerm", equalTo("0 years, 0 months"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].monthlyPaymentChanged", equalTo(true),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].diffMonthlyPayment", equalTo(new BigDecimal("0.94")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanInterestChanged", equalTo(true),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanInterestBeforeSimulation", equalTo(new BigDecimal("11754.02")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanInterestAfterSimulation", equalTo(new BigDecimal("10340.79")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].diffLoanInterestSimulation", equalTo(new BigDecimal("83.87")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].firstPaymentAfterOverpayment", equalTo(new BigDecimal("7889.52")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].secondPaymentAfterOverpayment", equalTo(new BigDecimal("7886.58")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].mortgageTermChanged", equalTo(false)
                );
    }

    @Test
    public void testHappyPathReduceTermOrPayment() {

        stubGetRegionHeartbeat();
        stubAnmfReduceTerm();
        stubAnmfReduceMonthlyPayments();
        stubAccountServiceOk();

        given().
                headers(headers).
                body(readFileContents("simulation/valid-simulation-request-term-or-payment.json")).
                when().
                put(simulationEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "dataResponse.simulationResponseList[0].simulationId", equalTo(6974492),
                        "dataResponse.simulationResponseList[0].totalOverpaymentAmount", equalTo(new BigDecimal("4992.07")),
                        "dataResponse.simulationResponseList[0].totalERC", equalTo(new BigDecimal("7.93")),
                        "dataResponse.simulationResponseList[0].totalPayment", equalTo(5000),
                        "dataResponse.simulationResponseList[0].totalAccountSimulationMonthlyPayment", equalTo(new BigDecimal("216.95")),
                        "dataResponse.simulationResponseList[0].totalNextMonthlyPayment", equalTo(new BigDecimal("7889.52")),
                        "dataResponse.simulationResponseList[0].totalSecondMonthlyPayment", equalTo(new BigDecimal("7886.58")),
                        "dataResponse.simulationResponseList[0].totalInterestBeforeSimulation", equalTo(new BigDecimal("11754.02")),
                        "dataResponse.simulationResponseList[0].totalInterestAfterSimulation", equalTo(new BigDecimal("8676.59")),
                        "dataResponse.simulationResponseList[0].diffInterest", equalTo(new BigDecimal("3077.43")),
                        "dataResponse.simulationResponseList[0].totalInterestChanged", equalTo(true),
                        "dataResponse.simulationResponseList[0].outstandingBalance", equalTo(new BigDecimal("36410.89")),
                        "dataResponse.simulationResponseList[0].totalTermReduction", equalTo(0),
                        "dataResponse.simulationResponseList[0].totalMonthlyPaymentReduction", equalTo(new BigDecimal("0.94")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanScheme", equalTo("3R"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].applicationSequenceNumber", equalTo(2),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanERC", equalTo(new BigDecimal("7.93")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].currentMonthlyPayment", equalTo(new BigDecimal("216.95")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].simulationMonthlyPayment", equalTo(new BigDecimal("216.95")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].currentMaturityDate", equalTo("07/10/2042"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].simulationMaturityDate", equalTo("07/09/2039"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].newMortgageTerm", not(null),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].newMortgageTerm", not(equalTo("")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].diffMortgageTerm", equalTo("3 years, 1 month"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].monthlyPaymentChanged", equalTo(true),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].diffMonthlyPayment", equalTo(new BigDecimal("0.94")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanInterestChanged", equalTo(true),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanInterestBeforeSimulation", equalTo(new BigDecimal("11754.02")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanInterestAfterSimulation", equalTo(new BigDecimal("8676.59")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].diffLoanInterestSimulation", equalTo(new BigDecimal("83.87")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].firstPaymentAfterOverpayment", equalTo(new BigDecimal("7889.52")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].secondPaymentAfterOverpayment", equalTo(new BigDecimal("7886.58")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].mortgageTermChanged", equalTo(false),
                        "dataResponse.simulationResponseList[1].simulationId", equalTo(6974492),
                        "dataResponse.simulationResponseList[1].totalOverpaymentAmount", equalTo(new BigDecimal("4992.07")),
                        "dataResponse.simulationResponseList[1].totalERC", equalTo(new BigDecimal("7.93")),
                        "dataResponse.simulationResponseList[1].totalPayment", equalTo(5000),
                        "dataResponse.simulationResponseList[1].totalAccountSimulationMonthlyPayment", equalTo(new BigDecimal("190.79")),
                        "dataResponse.simulationResponseList[1].totalNextMonthlyPayment", equalTo(new BigDecimal("7889.52")),
                        "dataResponse.simulationResponseList[1].totalSecondMonthlyPayment", equalTo(new BigDecimal("7886.58")),
                        "dataResponse.simulationResponseList[1].totalInterestBeforeSimulation", equalTo(new BigDecimal("11754.02")),
                        "dataResponse.simulationResponseList[1].totalInterestAfterSimulation", equalTo(new BigDecimal("10343.14")),
                        "dataResponse.simulationResponseList[1].diffInterest", equalTo(new BigDecimal("1410.88")),
                        "dataResponse.simulationResponseList[1].totalInterestChanged", equalTo(true),
                        "dataResponse.simulationResponseList[1].outstandingBalance", equalTo(new BigDecimal("36410.89")),
                        "dataResponse.simulationResponseList[1].totalMonthlyPaymentReduction", equalTo(new BigDecimal("0.94")),
                        "dataResponse.simulationResponseList[1].totalTermReduction", equalTo(0),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanScheme", equalTo("3R"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].applicationSequenceNumber", equalTo(2),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanERC", equalTo(new BigDecimal("7.93")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].currentMonthlyPayment", equalTo(new BigDecimal("216.95")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].simulationMonthlyPayment", equalTo(new BigDecimal("190.79")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].currentMaturityDate", equalTo("07/10/2042"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].simulationMaturityDate", equalTo("07/10/2042"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].newMortgageTerm", not(null),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].newMortgageTerm", not(equalTo("")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].diffMortgageTerm", equalTo("0 years, 0 months"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].monthlyPaymentChanged", equalTo(true),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].diffMonthlyPayment", equalTo(new BigDecimal("0.94")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanInterestChanged", equalTo(true),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanInterestBeforeSimulation", equalTo(new BigDecimal("11754.02")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanInterestAfterSimulation", equalTo(new BigDecimal("10343.14")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].diffLoanInterestSimulation", equalTo(new BigDecimal("83.87")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].firstPaymentAfterOverpayment", equalTo(new BigDecimal("7889.52")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].secondPaymentAfterOverpayment", equalTo(new BigDecimal("7886.58")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].mortgageTermChanged", equalTo(false)
                );
    }

    @Test
    public void testHappyPathSingleErc() {

        stubGetRegionHeartbeat();
        stubAnmfIncludeChargeReduceTerm12143533();
        stubAnmfIncludeChargeReduceMonthlyPayment12143533();
        stubAnmfAddChargeReduceTerm12143533();
        stubAnmfAddChargeReduceMonthlyPayment12143533();

        given().
                headers(headers).
                body(readFileContents("single-loan/simulation-controller-request-single.json")).
                when().
                put(simulationEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "dataResponse.simulationResponseList[0].simulationId", equalTo(200600677),
                        "dataResponse.simulationResponseList[0].totalOverpaymentAmount", equalTo(new BigDecimal("1470.59")),
                        "dataResponse.simulationResponseList[0].totalERC", equalTo(new BigDecimal("29.41")),
                        "dataResponse.simulationResponseList[0].totalPayment", equalTo(1500),
                        "dataResponse.simulationResponseList[0].totalAccountSimulationMonthlyPayment", equalTo(new BigDecimal("251.63")),
                        "dataResponse.simulationResponseList[0].totalNextMonthlyPayment", equalTo(new BigDecimal("251.71")),
                        "dataResponse.simulationResponseList[0].totalSecondMonthlyPayment", equalTo(new BigDecimal("251.62")),
                        "dataResponse.simulationResponseList[0].totalInterestBeforeSimulation", equalTo(new BigDecimal("1682.79")),
                        "dataResponse.simulationResponseList[0].totalInterestAfterSimulation", equalTo(new BigDecimal("1320.39")),
                        "dataResponse.simulationResponseList[0].diffInterest", equalTo(new BigDecimal("362.4")),
                        "dataResponse.simulationResponseList[0].totalInterestChanged", equalTo(true),
                        "dataResponse.simulationResponseList[0].outstandingBalance", equalTo(new BigDecimal("12196.5")),
                        "dataResponse.simulationResponseList[0].totalTermReduction", equalTo(7),
                        "dataResponse.simulationResponseList[0].totalMonthlyPaymentReduction", equalTo(0),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanScheme", equalTo("3R"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].applicationSequenceNumber", equalTo(3),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanERC", equalTo(new BigDecimal("29.41")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].currentMonthlyPayment", equalTo(new BigDecimal("251.63")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].simulationMonthlyPayment", equalTo(new BigDecimal("251.63")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].firstPaymentAfterOverpayment", equalTo(new BigDecimal("251.71")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].secondPaymentAfterOverpayment", equalTo(new BigDecimal("251.62")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].currentMaturityDate", equalTo("01/07/2028"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].simulationMaturityDate", equalTo("01/12/2027"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].newMortgageTerm", not(null),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].newMortgageTerm", not(equalTo("")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].diffMortgageTerm", equalTo("0 years, 7 months"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].mortgageTermChanged", equalTo(true),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].diffMonthlyPayment", equalTo(0),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].monthlyPaymentChanged", equalTo(false),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanInterestBeforeSimulation", equalTo(new BigDecimal("1682.79")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanInterestAfterSimulation", equalTo(new BigDecimal("1320.39")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].diffLoanInterestSimulation", equalTo(new BigDecimal("362.4")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanInterestChanged", equalTo(true),
                        "dataResponse.simulationResponseList[1].simulationId", equalTo(200600677),
                        "dataResponse.simulationResponseList[1].totalOverpaymentAmount", equalTo(new BigDecimal("1470.59")),
                        "dataResponse.simulationResponseList[1].totalERC", equalTo(new BigDecimal("29.41")),
                        "dataResponse.simulationResponseList[1].totalPayment", equalTo(1500),
                        "dataResponse.simulationResponseList[1].totalAccountSimulationMonthlyPayment", equalTo(new BigDecimal("224.55")),
                        "dataResponse.simulationResponseList[1].totalNextMonthlyPayment", equalTo(new BigDecimal("225.39")),
                        "dataResponse.simulationResponseList[1].totalSecondMonthlyPayment", equalTo(new BigDecimal("224.55")),
                        "dataResponse.simulationResponseList[1].totalInterestBeforeSimulation", equalTo(new BigDecimal("1682.79")),
                        "dataResponse.simulationResponseList[1].totalInterestAfterSimulation", equalTo(new BigDecimal("1502.55")),
                        "dataResponse.simulationResponseList[1].diffInterest", equalTo(new BigDecimal("180.24")),
                        "dataResponse.simulationResponseList[1].totalInterestChanged", equalTo(true),
                        "dataResponse.simulationResponseList[1].outstandingBalance", equalTo(new BigDecimal("12196.5")),
                        "dataResponse.simulationResponseList[1].totalTermReduction", equalTo(0),
                        "dataResponse.simulationResponseList[1].totalMonthlyPaymentReduction", equalTo(new BigDecimal("27.08")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanScheme", equalTo("3R"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].applicationSequenceNumber", equalTo(3),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanERC", equalTo(new BigDecimal("29.41")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].currentMonthlyPayment", equalTo(new BigDecimal("251.63")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].simulationMonthlyPayment", equalTo(new BigDecimal("224.55")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].firstPaymentAfterOverpayment", equalTo(new BigDecimal("225.39")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].secondPaymentAfterOverpayment", equalTo(new BigDecimal("224.55")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].currentMaturityDate", equalTo("01/07/2028"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].simulationMaturityDate", equalTo("01/07/2028"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].newMortgageTerm", not(null),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].newMortgageTerm", not(equalTo("")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].diffMortgageTerm", equalTo("0 years, 0 months"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].mortgageTermChanged", equalTo(false),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].diffMonthlyPayment", equalTo(new BigDecimal("27.08")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].monthlyPaymentChanged", equalTo(true),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanInterestBeforeSimulation", equalTo(new BigDecimal("1682.79")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanInterestAfterSimulation", equalTo(new BigDecimal("1502.55")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].diffLoanInterestSimulation", equalTo(new BigDecimal("180.24")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanInterestChanged", equalTo(true),
                        "dataResponse.simulationResponseList[2].simulationId", equalTo(200600677),
                        "dataResponse.simulationResponseList[2].totalOverpaymentAmount", equalTo(1500),
                        "dataResponse.simulationResponseList[2].totalERC", equalTo(30),
                        "dataResponse.simulationResponseList[2].totalPayment", equalTo(1530),
                        "dataResponse.simulationResponseList[2].totalAccountSimulationMonthlyPayment", equalTo(new BigDecimal("251.63")),
                        "dataResponse.simulationResponseList[2].totalNextMonthlyPayment", equalTo(new BigDecimal("251.71")),
                        "dataResponse.simulationResponseList[2].totalSecondMonthlyPayment", equalTo(new BigDecimal("251.62")),
                        "dataResponse.simulationResponseList[2].totalInterestBeforeSimulation", equalTo(new BigDecimal("1682.79")),
                        "dataResponse.simulationResponseList[2].totalInterestAfterSimulation", equalTo(new BigDecimal("1313.66")),
                        "dataResponse.simulationResponseList[2].diffInterest", equalTo(new BigDecimal("369.13")),
                        "dataResponse.simulationResponseList[2].totalInterestChanged", equalTo(true),
                        "dataResponse.simulationResponseList[2].outstandingBalance", equalTo(new BigDecimal("12167.09")),
                        "dataResponse.simulationResponseList[2].totalTermReduction", equalTo(7),
                        "dataResponse.simulationResponseList[2].totalMonthlyPaymentReduction", equalTo(0),
                        "dataResponse.simulationResponseList[2].outputLoanDataList[0].loanScheme", equalTo("3R"),
                        "dataResponse.simulationResponseList[2].outputLoanDataList[0].applicationSequenceNumber", equalTo(3),
                        "dataResponse.simulationResponseList[2].outputLoanDataList[0].loanERC", equalTo(30),
                        "dataResponse.simulationResponseList[2].outputLoanDataList[0].currentMonthlyPayment", equalTo(new BigDecimal("251.63")),
                        "dataResponse.simulationResponseList[2].outputLoanDataList[0].simulationMonthlyPayment", equalTo(new BigDecimal("251.63")),
                        "dataResponse.simulationResponseList[2].outputLoanDataList[0].firstPaymentAfterOverpayment", equalTo(new BigDecimal("251.71")),
                        "dataResponse.simulationResponseList[2].outputLoanDataList[0].secondPaymentAfterOverpayment", equalTo(new BigDecimal("251.62")),
                        "dataResponse.simulationResponseList[2].outputLoanDataList[0].currentMaturityDate", equalTo("01/07/2028"),
                        "dataResponse.simulationResponseList[2].outputLoanDataList[0].simulationMaturityDate", equalTo("01/12/2027"),
                        "dataResponse.simulationResponseList[2].outputLoanDataList[0].newMortgageTerm", not(null),
                        "dataResponse.simulationResponseList[2].outputLoanDataList[0].newMortgageTerm", not(equalTo("")),
                        "dataResponse.simulationResponseList[2].outputLoanDataList[0].diffMortgageTerm", equalTo("0 years, 7 months"),
                        "dataResponse.simulationResponseList[2].outputLoanDataList[0].mortgageTermChanged", equalTo(true),
                        "dataResponse.simulationResponseList[2].outputLoanDataList[0].diffMonthlyPayment", equalTo(0),
                        "dataResponse.simulationResponseList[2].outputLoanDataList[0].monthlyPaymentChanged", equalTo(false),
                        "dataResponse.simulationResponseList[2].outputLoanDataList[0].loanInterestBeforeSimulation", equalTo(new BigDecimal("1682.79")),
                        "dataResponse.simulationResponseList[2].outputLoanDataList[0].loanInterestAfterSimulation", equalTo(new BigDecimal("1313.66")),
                        "dataResponse.simulationResponseList[2].outputLoanDataList[0].diffLoanInterestSimulation", equalTo(new BigDecimal("369.13")),
                        "dataResponse.simulationResponseList[2].outputLoanDataList[0].loanInterestChanged", equalTo(true),
                        "dataResponse.simulationResponseList[3].simulationId", equalTo(200600677),
                        "dataResponse.simulationResponseList[3].totalOverpaymentAmount", equalTo(1500),
                        "dataResponse.simulationResponseList[3].totalERC", equalTo(30),
                        "dataResponse.simulationResponseList[3].totalPayment", equalTo(1530),
                        "dataResponse.simulationResponseList[3].totalAccountSimulationMonthlyPayment", equalTo(new BigDecimal("224.01")),
                        "dataResponse.simulationResponseList[3].totalNextMonthlyPayment", equalTo(new BigDecimal("224.86")),
                        "dataResponse.simulationResponseList[3].totalSecondMonthlyPayment", equalTo(new BigDecimal("224.01")),
                        "dataResponse.simulationResponseList[3].totalInterestBeforeSimulation", equalTo(new BigDecimal("1682.79")),
                        "dataResponse.simulationResponseList[3].totalInterestAfterSimulation", equalTo(new BigDecimal("1498.9")),
                        "dataResponse.simulationResponseList[3].diffInterest", equalTo(new BigDecimal("183.89")),
                        "dataResponse.simulationResponseList[3].totalInterestChanged", equalTo(true),
                        "dataResponse.simulationResponseList[3].outstandingBalance", equalTo(new BigDecimal("12167.09")),
                        "dataResponse.simulationResponseList[3].totalTermReduction", equalTo(0),
                        "dataResponse.simulationResponseList[3].totalMonthlyPaymentReduction", equalTo(new BigDecimal("27.62")),
                        "dataResponse.simulationResponseList[3].outputLoanDataList[0].loanScheme", equalTo("3R"),
                        "dataResponse.simulationResponseList[3].outputLoanDataList[0].applicationSequenceNumber", equalTo(3),
                        "dataResponse.simulationResponseList[3].outputLoanDataList[0].loanERC", equalTo(30),
                        "dataResponse.simulationResponseList[3].outputLoanDataList[0].currentMonthlyPayment", equalTo(new BigDecimal("251.63")),
                        "dataResponse.simulationResponseList[3].outputLoanDataList[0].simulationMonthlyPayment", equalTo(new BigDecimal("224.01")),
                        "dataResponse.simulationResponseList[3].outputLoanDataList[0].firstPaymentAfterOverpayment", equalTo(new BigDecimal("224.86")),
                        "dataResponse.simulationResponseList[3].outputLoanDataList[0].secondPaymentAfterOverpayment", equalTo(new BigDecimal("224.01")),
                        "dataResponse.simulationResponseList[3].outputLoanDataList[0].currentMaturityDate", equalTo("01/07/2028"),
                        "dataResponse.simulationResponseList[3].outputLoanDataList[0].simulationMaturityDate", equalTo("01/07/2028"),
                        "dataResponse.simulationResponseList[3].outputLoanDataList[0].newMortgageTerm", not(null),
                        "dataResponse.simulationResponseList[3].outputLoanDataList[0].newMortgageTerm", not(equalTo("")),
                        "dataResponse.simulationResponseList[3].outputLoanDataList[0].diffMortgageTerm", equalTo("0 years, 0 months"),
                        "dataResponse.simulationResponseList[3].outputLoanDataList[0].mortgageTermChanged", equalTo(false),
                        "dataResponse.simulationResponseList[3].outputLoanDataList[0].diffMonthlyPayment", equalTo(new BigDecimal("27.62")),
                        "dataResponse.simulationResponseList[3].outputLoanDataList[0].monthlyPaymentChanged", equalTo(true),
                        "dataResponse.simulationResponseList[3].outputLoanDataList[0].loanInterestBeforeSimulation", equalTo(new BigDecimal("1682.79")),
                        "dataResponse.simulationResponseList[3].outputLoanDataList[0].loanInterestAfterSimulation", equalTo(new BigDecimal("1498.9")),
                        "dataResponse.simulationResponseList[3].outputLoanDataList[0].diffLoanInterestSimulation", equalTo(new BigDecimal("183.89")),
                        "dataResponse.simulationResponseList[3].outputLoanDataList[0].loanInterestChanged", equalTo(true)

                );
    }


    @Test
    public void testHappyPathSingleInterestOnlyErc() {

        stubGetRegionHeartbeat();
        stubAnmfIncludeChargeReduceMonthlyPaymentSingleLoanInterestOnly();
        stubAnmfAddChargeReduceMonthlyPaymentSingleLoanInterestOnly();

        given().
                headers(headers).
                body(readFileContents("single-loan-interest-only/simulation-controller-request-single-loan-interest-only.json")).
                when().
                put(simulationEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "dataResponse.simulationResponseList[0].simulationId", equalTo(500054118),
                        "dataResponse.simulationResponseList[0].totalOverpaymentAmount", equalTo(new BigDecimal("5956.44")),
                        "dataResponse.simulationResponseList[0].totalERC", equalTo(new BigDecimal("43.56")),
                        "dataResponse.simulationResponseList[0].totalPayment", equalTo(6000),
                        "dataResponse.simulationResponseList[0].totalAccountSimulationMonthlyPayment", equalTo(75),
                        "dataResponse.simulationResponseList[0].totalNextMonthlyPayment", equalTo(new BigDecimal("76.19")),
                        "dataResponse.simulationResponseList[0].totalSecondMonthlyPayment", equalTo(75),
                        "dataResponse.simulationResponseList[0].totalInterestBeforeSimulation", equalTo(new BigDecimal("5536.74")),
                        "dataResponse.simulationResponseList[0].totalInterestAfterSimulation", equalTo(new BigDecimal("4951.19")),
                        "dataResponse.simulationResponseList[0].diffInterest", equalTo(new BigDecimal("585.55")),
                        "dataResponse.simulationResponseList[0].totalInterestChanged", equalTo(true),
                        "dataResponse.simulationResponseList[0].outstandingBalance", equalTo(new BigDecimal("50280.57")),
                        "dataResponse.simulationResponseList[0].totalTermReduction", equalTo(0),
                        "dataResponse.simulationResponseList[0].totalMonthlyPaymentReduction", equalTo(new BigDecimal("8.89")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanScheme", equalTo("3I"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].applicationSequenceNumber", equalTo(8),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanERC", equalTo(new BigDecimal("43.56")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].currentMonthlyPayment", equalTo(new BigDecimal("83.89")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].simulationMonthlyPayment", equalTo(75),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].firstPaymentAfterOverpayment", equalTo(new BigDecimal("76.19")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].secondPaymentAfterOverpayment", equalTo(75),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].currentMaturityDate", equalTo("01/12/2028"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].simulationMaturityDate", equalTo("01/12/2028"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].newMortgageTerm", not(null),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].newMortgageTerm", not(equalTo("")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].diffMortgageTerm", equalTo("0 years, 0 months"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].mortgageTermChanged", equalTo(false),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].diffMonthlyPayment", equalTo(new BigDecimal("8.89")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].monthlyPaymentChanged", equalTo(true),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanInterestBeforeSimulation", equalTo(new BigDecimal("5536.74")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanInterestAfterSimulation", equalTo(new BigDecimal("4951.19")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].diffLoanInterestSimulation", equalTo(new BigDecimal("585.55")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanInterestChanged", equalTo(true),
                        "dataResponse.simulationResponseList[1].simulationId", equalTo(500054118),
                        "dataResponse.simulationResponseList[1].totalOverpaymentAmount", equalTo(6000),
                        "dataResponse.simulationResponseList[1].totalERC", equalTo(new BigDecimal("45.74")),
                        "dataResponse.simulationResponseList[1].totalPayment", equalTo(new BigDecimal("6045.74")),
                        "dataResponse.simulationResponseList[1].totalAccountSimulationMonthlyPayment", equalTo(new BigDecimal("74.94")),
                        "dataResponse.simulationResponseList[1].totalNextMonthlyPayment", equalTo(new BigDecimal("76.13")),
                        "dataResponse.simulationResponseList[1].totalSecondMonthlyPayment", equalTo(new BigDecimal("74.94")),
                        "dataResponse.simulationResponseList[1].totalInterestBeforeSimulation", equalTo(new BigDecimal("5536.74")),
                        "dataResponse.simulationResponseList[1].totalInterestAfterSimulation", equalTo(new BigDecimal("4947.23")),
                        "dataResponse.simulationResponseList[1].diffInterest", equalTo(new BigDecimal("589.51")),
                        "dataResponse.simulationResponseList[1].totalInterestChanged", equalTo(true),
                        "dataResponse.simulationResponseList[1].outstandingBalance", equalTo(new BigDecimal("50237.01")),
                        "dataResponse.simulationResponseList[1].totalTermReduction", equalTo(0),
                        "dataResponse.simulationResponseList[1].totalMonthlyPaymentReduction", equalTo(new BigDecimal("8.95")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanScheme", equalTo("3I"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].applicationSequenceNumber", equalTo(8),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanERC", equalTo(new BigDecimal("45.74")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].currentMonthlyPayment", equalTo(new BigDecimal("83.89")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].simulationMonthlyPayment", equalTo(new BigDecimal("74.94")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].firstPaymentAfterOverpayment", equalTo(new BigDecimal("76.13")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].secondPaymentAfterOverpayment", equalTo(new BigDecimal("74.94")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].currentMaturityDate", equalTo("01/12/2028"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].simulationMaturityDate", equalTo("01/12/2028"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].newMortgageTerm", not(null),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].newMortgageTerm", not(equalTo("")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].diffMortgageTerm", equalTo("0 years, 0 months"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].mortgageTermChanged", equalTo(false),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].diffMonthlyPayment", equalTo(new BigDecimal("8.95")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].monthlyPaymentChanged", equalTo(true),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanInterestBeforeSimulation", equalTo(new BigDecimal("5536.74")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanInterestAfterSimulation", equalTo(new BigDecimal("4947.23")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].diffLoanInterestSimulation", equalTo(new BigDecimal("589.51")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanInterestChanged", equalTo(true)

                );
    }


    @Test
    public void testHappyPathMultiLoanFixedOneLoanOverpaid() {

        stubGetRegionHeartbeat();
        stubAnmfIncludeChargeReduceTermMultiLoanFixedOneLoanOverpaid();
        stubAnmfIncludeChargeReduceMonthlyPaymentMultiLoanFixedOneLoanOverpaid();

        given().
                headers(headers).
                body(readFileContents("multi-loan-3-fixed-one-loan-overpaid/simulation-controller-request-multi-loan-3-fixed-one-loan-overpaid.json")).
                when().
                put(simulationEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "dataResponse.simulationResponseList[0].simulationId", equalTo(200604934),
                        "dataResponse.simulationResponseList[0].totalOverpaymentAmount", equalTo(2000),
                        "dataResponse.simulationResponseList[0].totalERC", equalTo(0),
                        "dataResponse.simulationResponseList[0].totalPayment", equalTo(2000),
                        "dataResponse.simulationResponseList[0].totalAccountSimulationMonthlyPayment", equalTo(new BigDecimal("2509.74")),
                        "dataResponse.simulationResponseList[0].totalNextMonthlyPayment", equalTo(new BigDecimal("2509.74")),
                        "dataResponse.simulationResponseList[0].totalSecondMonthlyPayment", equalTo(new BigDecimal("2509.75")),
                        "dataResponse.simulationResponseList[0].totalInterestBeforeSimulation", equalTo(new BigDecimal("63114.84")),
                        "dataResponse.simulationResponseList[0].totalInterestAfterSimulation", equalTo(new BigDecimal("62309.32")),
                        "dataResponse.simulationResponseList[0].diffInterest", equalTo(new BigDecimal("805.52")),
                        "dataResponse.simulationResponseList[0].totalInterestChanged", equalTo(true),
                        "dataResponse.simulationResponseList[0].outstandingBalance", equalTo(new BigDecimal("401148.26")),
                        "dataResponse.simulationResponseList[0].totalTermReduction", equalTo(1),
                        "dataResponse.simulationResponseList[0].totalMonthlyPaymentReduction", equalTo(0),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanScheme", equalTo("3T"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].applicationSequenceNumber", equalTo(3),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanERC", equalTo(0),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].currentMonthlyPayment", equalTo(new BigDecimal("600.66")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].simulationMonthlyPayment", equalTo(new BigDecimal("600.66")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].firstPaymentAfterOverpayment", equalTo(new BigDecimal("600.66")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].secondPaymentAfterOverpayment", equalTo(new BigDecimal("600.66")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].currentMaturityDate", equalTo("05/11/2038"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].simulationMaturityDate", equalTo("05/11/2038"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].newMortgageTerm", not(null),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].newMortgageTerm", not(equalTo("")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].diffMortgageTerm", equalTo("0 years, 0 months"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].mortgageTermChanged", equalTo(false),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].diffMonthlyPayment", equalTo(0),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].monthlyPaymentChanged", equalTo(false),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanInterestBeforeSimulation", equalTo(new BigDecimal("8878.6")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanInterestAfterSimulation", equalTo(new BigDecimal("8878.61")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].diffLoanInterestSimulation", equalTo(new BigDecimal("-0.01")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanInterestChanged", equalTo(false),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].loanScheme", equalTo("3R"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].applicationSequenceNumber", equalTo(5),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].loanERC", equalTo(0),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].currentMonthlyPayment", equalTo(new BigDecimal("1864.25")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].simulationMonthlyPayment", equalTo(new BigDecimal("1864.25")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].firstPaymentAfterOverpayment", equalTo(new BigDecimal("1864.25")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].secondPaymentAfterOverpayment", equalTo(new BigDecimal("1864.25")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].currentMaturityDate", equalTo("05/12/2038"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].simulationMaturityDate", equalTo("05/11/2038"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].newMortgageTerm", not(null),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].newMortgageTerm", not(equalTo("")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].diffMortgageTerm", equalTo("0 years, 1 month"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].mortgageTermChanged", equalTo(true),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].diffMonthlyPayment", equalTo(0),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].monthlyPaymentChanged", equalTo(false),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].loanInterestBeforeSimulation", equalTo(new BigDecimal("52948.51")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].loanInterestAfterSimulation", equalTo(new BigDecimal("52142.98")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].diffLoanInterestSimulation", equalTo(new BigDecimal("805.53")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].loanInterestChanged", equalTo(true),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].loanScheme", equalTo("3R"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].applicationSequenceNumber", equalTo(6),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].loanERC", equalTo(0),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].currentMonthlyPayment", equalTo(new BigDecimal("44.83")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].simulationMonthlyPayment", equalTo(new BigDecimal("44.83")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].firstPaymentAfterOverpayment", equalTo(new BigDecimal("44.83")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].secondPaymentAfterOverpayment", equalTo(new BigDecimal("44.84")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].currentMaturityDate", equalTo("05/01/2039"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].simulationMaturityDate", equalTo("05/01/2039"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].newMortgageTerm", not(null),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].newMortgageTerm", not(equalTo("")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].diffMortgageTerm", equalTo("0 years, 0 months"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].mortgageTermChanged", equalTo(false),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].diffMonthlyPayment", equalTo(0),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].monthlyPaymentChanged", equalTo(false),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].loanInterestBeforeSimulation", equalTo(new BigDecimal("1287.73")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].loanInterestAfterSimulation", equalTo(new BigDecimal("1287.73")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].diffLoanInterestSimulation", equalTo(0),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].loanInterestChanged", equalTo(false),
                        "dataResponse.simulationResponseList[1].simulationId", equalTo(200604934),
                        "dataResponse.simulationResponseList[1].totalOverpaymentAmount", equalTo(2000),
                        "dataResponse.simulationResponseList[1].totalERC", equalTo(0),
                        "dataResponse.simulationResponseList[1].totalPayment", equalTo(2000),
                        "dataResponse.simulationResponseList[1].totalAccountSimulationMonthlyPayment", equalTo(new BigDecimal("2497.05")),
                        "dataResponse.simulationResponseList[1].totalNextMonthlyPayment", equalTo(new BigDecimal("2497.18")),
                        "dataResponse.simulationResponseList[1].totalSecondMonthlyPayment", equalTo(new BigDecimal("2497.07")),
                        "dataResponse.simulationResponseList[1].totalInterestBeforeSimulation", equalTo(new BigDecimal("63114.84")),
                        "dataResponse.simulationResponseList[1].totalInterestAfterSimulation", equalTo(new BigDecimal("62754.61")),
                        "dataResponse.simulationResponseList[1].diffInterest", equalTo(new BigDecimal("360.23")),
                        "dataResponse.simulationResponseList[1].totalInterestChanged", equalTo(true),
                        "dataResponse.simulationResponseList[1].outstandingBalance", equalTo(new BigDecimal("401148.26")),
                        "dataResponse.simulationResponseList[1].totalTermReduction", equalTo(0),
                        "dataResponse.simulationResponseList[1].totalMonthlyPaymentReduction", equalTo(new BigDecimal("12.69")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanScheme", equalTo("3T"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].applicationSequenceNumber", equalTo(3),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanERC", equalTo(0),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].currentMonthlyPayment", equalTo(new BigDecimal("600.66")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].simulationMonthlyPayment", equalTo(new BigDecimal("600.66")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].firstPaymentAfterOverpayment", equalTo(new BigDecimal("600.66")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].secondPaymentAfterOverpayment", equalTo(new BigDecimal("600.66")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].currentMaturityDate", equalTo("05/11/2038"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].simulationMaturityDate", equalTo("05/11/2038"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].newMortgageTerm", not(null),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].newMortgageTerm", not(equalTo("")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].diffMortgageTerm", equalTo("0 years, 0 months"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].mortgageTermChanged", equalTo(false),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].diffMonthlyPayment", equalTo(0),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].monthlyPaymentChanged", equalTo(false),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanInterestBeforeSimulation", equalTo(new BigDecimal("8878.6")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanInterestAfterSimulation", equalTo(new BigDecimal("8878.61")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].diffLoanInterestSimulation", equalTo(new BigDecimal("-0.01")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanInterestChanged", equalTo(false),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].loanScheme", equalTo("3R"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].applicationSequenceNumber", equalTo(5),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].loanERC", equalTo(0),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].currentMonthlyPayment", equalTo(new BigDecimal("1864.25")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].simulationMonthlyPayment", equalTo(new BigDecimal("1851.56")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].firstPaymentAfterOverpayment", equalTo(new BigDecimal("1851.69")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].secondPaymentAfterOverpayment", equalTo(new BigDecimal("1851.57")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].currentMaturityDate", equalTo("05/12/2038"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].simulationMaturityDate", equalTo("05/12/2038"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].newMortgageTerm", not(null),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].newMortgageTerm", not(equalTo("")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].diffMortgageTerm", equalTo("0 years, 0 months"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].mortgageTermChanged", equalTo(false),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].diffMonthlyPayment", equalTo(new BigDecimal("12.69")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].monthlyPaymentChanged", equalTo(true),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].loanInterestBeforeSimulation", equalTo(new BigDecimal("52948.51")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].loanInterestAfterSimulation", equalTo(new BigDecimal("52588.27")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].diffLoanInterestSimulation", equalTo(new BigDecimal("360.24")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].loanInterestChanged", equalTo(true),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].loanScheme", equalTo("3R"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].applicationSequenceNumber", equalTo(6),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].loanERC", equalTo(0),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].currentMonthlyPayment", equalTo(new BigDecimal("44.83")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].simulationMonthlyPayment", equalTo(new BigDecimal("44.83")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].firstPaymentAfterOverpayment", equalTo(new BigDecimal("44.83")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].secondPaymentAfterOverpayment", equalTo(new BigDecimal("44.84")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].currentMaturityDate", equalTo("05/01/2039"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].simulationMaturityDate", equalTo("05/01/2039"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].newMortgageTerm", not(null),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].newMortgageTerm", not(equalTo("")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].diffMortgageTerm", equalTo("0 years, 0 months"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].mortgageTermChanged", equalTo(false),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].diffMonthlyPayment", equalTo(0),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].monthlyPaymentChanged", equalTo(false),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].loanInterestBeforeSimulation", equalTo(new BigDecimal("1287.73")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].loanInterestAfterSimulation", equalTo(new BigDecimal("1287.73")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].diffLoanInterestSimulation", equalTo(0),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].loanInterestChanged", equalTo(false)

                );
    }

    @Test
    public void testHappyPathMultiLoanFixedAllLoanOverpaid() {

        stubGetRegionHeartbeat();
        stubAnmfIncludeChargeReduceTermMultiLoanFixedAllLoansOverpaid();
        stubAnmfAddChargeReduceTermMultiLoanFixedAllLoansOverpaid();

        given().
                headers(headers).
                body(readFileContents("multi-loan-3-fixed-all-loans-overpaid/simulation-controller-request-multi-loan-3-fixed-all-loans-overpaid.json")).
                when().
                put(simulationEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "dataResponse.simulationResponseList[0].simulationId", equalTo(200604962),
                        "dataResponse.simulationResponseList[0].totalOverpaymentAmount", equalTo(6000),
                        "dataResponse.simulationResponseList[0].totalERC", equalTo(0),
                        "dataResponse.simulationResponseList[0].totalPayment", equalTo(6000),
                        "dataResponse.simulationResponseList[0].totalAccountSimulationMonthlyPayment", equalTo(new BigDecimal("2509.74")),
                        "dataResponse.simulationResponseList[0].totalNextMonthlyPayment", equalTo(new BigDecimal("2509.74")),
                        "dataResponse.simulationResponseList[0].totalSecondMonthlyPayment", equalTo(new BigDecimal("2509.75")),
                        "dataResponse.simulationResponseList[0].totalInterestBeforeSimulation", equalTo(new BigDecimal("63114.84")),
                        "dataResponse.simulationResponseList[0].totalInterestAfterSimulation", equalTo(new BigDecimal("61229.47")),
                        "dataResponse.simulationResponseList[0].diffInterest", equalTo(new BigDecimal("1885.37")),
                        "dataResponse.simulationResponseList[0].totalInterestChanged", equalTo(true),
                        "dataResponse.simulationResponseList[0].outstandingBalance", equalTo(new BigDecimal("397148.26")),
                        "dataResponse.simulationResponseList[0].totalTermReduction", equalTo(86),
                        "dataResponse.simulationResponseList[0].totalMonthlyPaymentReduction", equalTo(0),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanScheme", equalTo("3T"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].applicationSequenceNumber", equalTo(3),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanERC", equalTo(0),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].currentMonthlyPayment", equalTo(new BigDecimal("600.66")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].simulationMonthlyPayment", equalTo(new BigDecimal("600.66")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].firstPaymentAfterOverpayment", equalTo(new BigDecimal("600.66")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].secondPaymentAfterOverpayment", equalTo(new BigDecimal("600.66")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].currentMaturityDate", equalTo("05/11/2038"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].simulationMaturityDate", equalTo("05/10/2038"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].newMortgageTerm", not(null),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].newMortgageTerm", not(equalTo("")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].diffMortgageTerm", equalTo("0 years, 1 month"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].mortgageTermChanged", equalTo(true),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].diffMonthlyPayment", equalTo(0),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].monthlyPaymentChanged", equalTo(false),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanInterestBeforeSimulation", equalTo(new BigDecimal("8878.6")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanInterestAfterSimulation", equalTo(new BigDecimal("8696.24")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].diffLoanInterestSimulation", equalTo(new BigDecimal("182.36")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanInterestChanged", equalTo(true),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].loanScheme", equalTo("3R"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].applicationSequenceNumber", equalTo(5),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].loanERC", equalTo(0),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].currentMonthlyPayment", equalTo(new BigDecimal("1864.25")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].simulationMonthlyPayment", equalTo(new BigDecimal("1864.25")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].firstPaymentAfterOverpayment", equalTo(new BigDecimal("1864.25")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].secondPaymentAfterOverpayment", equalTo(new BigDecimal("1864.25")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].currentMaturityDate", equalTo("05/12/2038"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].simulationMaturityDate", equalTo("05/11/2038"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].newMortgageTerm", not(null),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].newMortgageTerm", not(equalTo("")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].diffMortgageTerm", equalTo("0 years, 1 month"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].mortgageTermChanged", equalTo(true),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].diffMonthlyPayment", equalTo(0),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].monthlyPaymentChanged", equalTo(false),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].loanInterestBeforeSimulation", equalTo(new BigDecimal("52948.51")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].loanInterestAfterSimulation", equalTo(new BigDecimal("52142.98")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].diffLoanInterestSimulation", equalTo(new BigDecimal("805.53")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].loanInterestChanged", equalTo(true),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].loanScheme", equalTo("3R"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].applicationSequenceNumber", equalTo(6),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].loanERC", equalTo(0),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].currentMonthlyPayment", equalTo(new BigDecimal("44.83")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].simulationMonthlyPayment", equalTo(new BigDecimal("44.83")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].firstPaymentAfterOverpayment", equalTo(new BigDecimal("44.83")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].secondPaymentAfterOverpayment", equalTo(new BigDecimal("44.84")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].currentMaturityDate", equalTo("05/01/2039"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].simulationMaturityDate", equalTo("05/11/2031"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].newMortgageTerm", not(null),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].newMortgageTerm", not(equalTo("")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].diffMortgageTerm", equalTo("7 years, 2 months"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].mortgageTermChanged", equalTo(true),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].diffMonthlyPayment", equalTo(0),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].monthlyPaymentChanged", equalTo(false),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].loanInterestBeforeSimulation", equalTo(new BigDecimal("1287.73")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].loanInterestAfterSimulation", equalTo(new BigDecimal("390.25")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].diffLoanInterestSimulation", equalTo(new BigDecimal("897.48")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[2].loanInterestChanged", equalTo(true),
                        "dataResponse.simulationResponseList[1].simulationId", equalTo(200604962),
                        "dataResponse.simulationResponseList[1].totalOverpaymentAmount", equalTo(6000),
                        "dataResponse.simulationResponseList[1].totalERC", equalTo(0),
                        "dataResponse.simulationResponseList[1].totalPayment", equalTo(6000),
                        "dataResponse.simulationResponseList[1].totalAccountSimulationMonthlyPayment", equalTo(new BigDecimal("2509.74")),
                        "dataResponse.simulationResponseList[1].totalNextMonthlyPayment", equalTo(new BigDecimal("2509.74")),
                        "dataResponse.simulationResponseList[1].totalSecondMonthlyPayment", equalTo(new BigDecimal("2509.75")),
                        "dataResponse.simulationResponseList[1].totalInterestBeforeSimulation", equalTo(new BigDecimal("63114.84")),
                        "dataResponse.simulationResponseList[1].totalInterestAfterSimulation", equalTo(new BigDecimal("61229.47")),
                        "dataResponse.simulationResponseList[1].diffInterest", equalTo(new BigDecimal("1885.37")),
                        "dataResponse.simulationResponseList[1].totalInterestChanged", equalTo(true),
                        "dataResponse.simulationResponseList[1].outstandingBalance", equalTo(new BigDecimal("397148.26")),
                        "dataResponse.simulationResponseList[1].totalTermReduction", equalTo(86),
                        "dataResponse.simulationResponseList[1].totalMonthlyPaymentReduction", equalTo(0),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanScheme", equalTo("3T"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].applicationSequenceNumber", equalTo(3),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanERC", equalTo(0),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].currentMonthlyPayment", equalTo(new BigDecimal("600.66")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].simulationMonthlyPayment", equalTo(new BigDecimal("600.66")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].firstPaymentAfterOverpayment", equalTo(new BigDecimal("600.66")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].secondPaymentAfterOverpayment", equalTo(new BigDecimal("600.66")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].currentMaturityDate", equalTo("05/11/2038"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].simulationMaturityDate", equalTo("05/10/2038"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].newMortgageTerm", not(null),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].newMortgageTerm", not(equalTo("")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].diffMortgageTerm", equalTo("0 years, 1 month"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].mortgageTermChanged", equalTo(true),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].diffMonthlyPayment", equalTo(0),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].monthlyPaymentChanged", equalTo(false),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanInterestBeforeSimulation", equalTo(new BigDecimal("8878.6")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanInterestAfterSimulation", equalTo(new BigDecimal("8696.24")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].diffLoanInterestSimulation", equalTo(new BigDecimal("182.36")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanInterestChanged", equalTo(true),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].loanScheme", equalTo("3R"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].applicationSequenceNumber", equalTo(5),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].loanERC", equalTo(0),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].currentMonthlyPayment", equalTo(new BigDecimal("1864.25")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].simulationMonthlyPayment", equalTo(new BigDecimal("1864.25")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].firstPaymentAfterOverpayment", equalTo(new BigDecimal("1864.25")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].secondPaymentAfterOverpayment", equalTo(new BigDecimal("1864.25")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].currentMaturityDate", equalTo("05/12/2038"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].simulationMaturityDate", equalTo("05/11/2038"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].newMortgageTerm", not(null),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].newMortgageTerm", not(equalTo("")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].diffMortgageTerm", equalTo("0 years, 1 month"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].mortgageTermChanged", equalTo(true),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].diffMonthlyPayment", equalTo(0),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].monthlyPaymentChanged", equalTo(false),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].loanInterestBeforeSimulation", equalTo(new BigDecimal("52948.51")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].loanInterestAfterSimulation", equalTo(new BigDecimal("52142.98")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].diffLoanInterestSimulation", equalTo(new BigDecimal("805.53")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].loanInterestChanged", equalTo(true),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].loanScheme", equalTo("3R"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].applicationSequenceNumber", equalTo(6),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].loanERC", equalTo(0),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].currentMonthlyPayment", equalTo(new BigDecimal("44.83")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].simulationMonthlyPayment", equalTo(new BigDecimal("44.83")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].firstPaymentAfterOverpayment", equalTo(new BigDecimal("44.83")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].secondPaymentAfterOverpayment", equalTo(new BigDecimal("44.84")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].currentMaturityDate", equalTo("05/01/2039"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].simulationMaturityDate", equalTo("05/11/2031"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].newMortgageTerm", not(null),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].newMortgageTerm", not(equalTo("")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].diffMortgageTerm", equalTo("7 years, 2 months"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].mortgageTermChanged", equalTo(true),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].diffMonthlyPayment", equalTo(0),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].monthlyPaymentChanged", equalTo(false),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].loanInterestBeforeSimulation", equalTo(new BigDecimal("1287.73")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].loanInterestAfterSimulation", equalTo(new BigDecimal("390.25")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].diffLoanInterestSimulation", equalTo(new BigDecimal("897.48")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[2].loanInterestChanged", equalTo(true)

                );
    }

    @Test
    public void testHappyPathMultiLoanCombinedAllowance() {

        stubGetRegionHeartbeat();
        stubAnmfIncludeChargeReduceTermMultiLoanCombinedAllowance();
        stubAnmfAddChargeReduceTermMultiLoanCombinedAllowance();

        given().
                headers(headers).
                body(readFileContents("multi-loan-2-loans-combined-allowance/simulation-controller-request-multi-loan-combined-allowance.json")).
                when().
                put(simulationEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "dataResponse.simulationResponseList[0].simulationId", equalTo(200607582),
                        "dataResponse.simulationResponseList[0].totalOverpaymentAmount", equalTo(new BigDecimal("5986.66")),
                        "dataResponse.simulationResponseList[0].totalERC", equalTo(new BigDecimal("13.34")),
                        "dataResponse.simulationResponseList[0].totalPayment", equalTo(6000),
                        "dataResponse.simulationResponseList[0].totalAccountSimulationMonthlyPayment", equalTo(new BigDecimal("709.56")),
                        "dataResponse.simulationResponseList[0].totalNextMonthlyPayment", equalTo(new BigDecimal("709.56")),
                        "dataResponse.simulationResponseList[0].totalSecondMonthlyPayment", equalTo(new BigDecimal("709.55")),
                        "dataResponse.simulationResponseList[0].totalInterestBeforeSimulation", equalTo(new BigDecimal("3066.07")),
                        "dataResponse.simulationResponseList[0].totalInterestAfterSimulation", equalTo(new BigDecimal("2452.87")),
                        "dataResponse.simulationResponseList[0].diffInterest", equalTo(new BigDecimal("613.2")),
                        "dataResponse.simulationResponseList[0].totalInterestChanged", equalTo(true),
                        "dataResponse.simulationResponseList[0].outstandingBalance", equalTo(new BigDecimal("45657.56")),
                        "dataResponse.simulationResponseList[0].totalTermReduction", equalTo(44),
                        "dataResponse.simulationResponseList[0].totalMonthlyPaymentReduction", equalTo(0),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanScheme", equalTo("3R"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].applicationSequenceNumber", equalTo(7),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanERC", equalTo(0),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].currentMonthlyPayment", equalTo(new BigDecimal("636.67")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].simulationMonthlyPayment", equalTo(new BigDecimal("636.67")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].firstPaymentAfterOverpayment", equalTo(new BigDecimal("636.67")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].secondPaymentAfterOverpayment", equalTo(new BigDecimal("636.67")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].currentMaturityDate", equalTo("02/11/2029"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].simulationMaturityDate", equalTo("02/06/2029"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].newMortgageTerm", not(null),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].newMortgageTerm", not(equalTo("")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].diffMortgageTerm", equalTo("0 years, 5 months"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].mortgageTermChanged", equalTo(true),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].diffMonthlyPayment", equalTo(0),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].monthlyPaymentChanged", equalTo(false),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanInterestBeforeSimulation", equalTo(new BigDecimal("2743.63")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanInterestAfterSimulation", equalTo(new BigDecimal("2390.36")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].diffLoanInterestSimulation", equalTo(new BigDecimal("353.27")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[0].loanInterestChanged", equalTo(true),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].loanScheme", equalTo("3R"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].applicationSequenceNumber", equalTo(8),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].loanERC", equalTo(new BigDecimal("13.34")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].currentMonthlyPayment", equalTo(new BigDecimal("72.89")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].simulationMonthlyPayment", equalTo(new BigDecimal("72.89")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].firstPaymentAfterOverpayment", equalTo(new BigDecimal("72.89")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].secondPaymentAfterOverpayment", equalTo(new BigDecimal("72.88")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].currentMaturityDate", equalTo("02/12/2029"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].simulationMaturityDate", equalTo("02/04/2026"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].newMortgageTerm", not(null),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].newMortgageTerm", not(equalTo("")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].diffMortgageTerm", equalTo("3 years, 8 months"),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].mortgageTermChanged", equalTo(true),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].diffMonthlyPayment", equalTo(0),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].monthlyPaymentChanged", equalTo(false),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].loanInterestBeforeSimulation", equalTo(new BigDecimal("322.44")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].loanInterestAfterSimulation", equalTo(new BigDecimal("62.51")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].diffLoanInterestSimulation", equalTo(new BigDecimal("259.93")),
                        "dataResponse.simulationResponseList[0].outputLoanDataList[1].loanInterestChanged", equalTo(true),

                        "dataResponse.simulationResponseList[1].simulationId", equalTo(200607583),
                        "dataResponse.simulationResponseList[1].totalOverpaymentAmount", equalTo(6000),
                        "dataResponse.simulationResponseList[1].totalERC", equalTo(new BigDecimal("13.74")),
                        "dataResponse.simulationResponseList[1].totalPayment", equalTo(new BigDecimal("6013.74")),
                        "dataResponse.simulationResponseList[1].totalAccountSimulationMonthlyPayment", equalTo(new BigDecimal("709.56")),
                        "dataResponse.simulationResponseList[1].totalNextMonthlyPayment", equalTo(new BigDecimal("709.56")),
                        "dataResponse.simulationResponseList[1].totalSecondMonthlyPayment", equalTo(new BigDecimal("709.55")),
                        "dataResponse.simulationResponseList[1].totalInterestBeforeSimulation", equalTo(new BigDecimal("3066.07")),
                        "dataResponse.simulationResponseList[1].totalInterestAfterSimulation", equalTo(new BigDecimal("2452.17")),
                        "dataResponse.simulationResponseList[1].diffInterest", equalTo(new BigDecimal("613.9")),
                        "dataResponse.simulationResponseList[1].totalInterestChanged", equalTo(true),
                        "dataResponse.simulationResponseList[1].outstandingBalance", equalTo(new BigDecimal("45644.22")),
                        "dataResponse.simulationResponseList[1].totalTermReduction", equalTo(44),
                        "dataResponse.simulationResponseList[1].totalMonthlyPaymentReduction", equalTo(0),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanScheme", equalTo("3R"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].applicationSequenceNumber", equalTo(7),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanERC", equalTo(0),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].currentMonthlyPayment", equalTo(new BigDecimal("636.67")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].simulationMonthlyPayment", equalTo(new BigDecimal("636.67")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].firstPaymentAfterOverpayment", equalTo(new BigDecimal("636.67")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].secondPaymentAfterOverpayment", equalTo(new BigDecimal("636.67")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].currentMaturityDate", equalTo("02/11/2029"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].simulationMaturityDate", equalTo("02/06/2029"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].newMortgageTerm", not(null),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].newMortgageTerm", not(equalTo("")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].diffMortgageTerm", equalTo("0 years, 5 months"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].mortgageTermChanged", equalTo(true),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].diffMonthlyPayment", equalTo(0),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].monthlyPaymentChanged", equalTo(false),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanInterestBeforeSimulation", equalTo(new BigDecimal("2743.63")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanInterestAfterSimulation", equalTo(new BigDecimal("2390.36")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].diffLoanInterestSimulation", equalTo(new BigDecimal("353.27")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[0].loanInterestChanged", equalTo(true),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].loanScheme", equalTo("3R"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].applicationSequenceNumber", equalTo(8),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].loanERC", equalTo(new BigDecimal("13.74")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].currentMonthlyPayment", equalTo(new BigDecimal("72.89")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].simulationMonthlyPayment", equalTo(new BigDecimal("72.89")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].firstPaymentAfterOverpayment", equalTo(new BigDecimal("72.89")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].secondPaymentAfterOverpayment", equalTo(new BigDecimal("72.88")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].currentMaturityDate", equalTo("02/12/2029"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].simulationMaturityDate", equalTo("02/04/2026"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].newMortgageTerm", not(null),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].newMortgageTerm", not(equalTo("")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].diffMortgageTerm", equalTo("3 years, 8 months"),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].mortgageTermChanged", equalTo(true),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].diffMonthlyPayment", equalTo(0),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].monthlyPaymentChanged", equalTo(false),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].loanInterestBeforeSimulation", equalTo(new BigDecimal("322.44")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].loanInterestAfterSimulation", equalTo(new BigDecimal("61.81")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].diffLoanInterestSimulation", equalTo(new BigDecimal("260.63")),
                        "dataResponse.simulationResponseList[1].outputLoanDataList[1].loanInterestChanged", equalTo(true)

                );
    }
}
