package com.santanderuk.corinthian.hub.simulations.api.simulation;

import com.santanderuk.corinthian.hub.simulations.TestDataCreator;
import com.santanderuk.corinthian.hub.simulations.api.simulation.model.SimulationControllerResponse;
import com.santanderuk.corinthian.hub.simulations.api.simulation.model.SimulationListInput;
import com.santanderuk.corinthian.hub.simulations.api.simulation.services.SimulationService;
import com.santanderuk.corinthian.hub.simulations.config.AnmfConfig;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.HeartBeatClient;
import com.santanderuk.corinthian.services.commons.exceptions.*;
import com.santanderuk.corinthian.services.commons.operativesecurity.AnmfBelongToCustomerService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.*;

@ActiveProfiles("test")
@SpringBootTest
@ExtendWith(SpringExtension.class)
class SimulationControllerTest {
    @MockBean
    AnmfConfig anmfConfig;
    @Autowired
    private SimulationController simulationController;
    @MockBean
    private AnmfBelongToCustomerService anmfBelongToCustomerService;

    @MockBean
    private HeartBeatClient heartBeatClient;

    @MockBean
    private SimulationService simulationService;

    @BeforeEach
    void setUp() throws MaintenanceException, ConnectionException {
        Mockito.when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);
    }

    @Test
    void testHappyPath() throws IOException, GeneralException {
        Mockito.when(anmfConfig.isOperativeSecurity()).thenReturn(true);
        Mockito.when(anmfConfig.getAnmfCustomerServiceUrl()).thenReturn("customerServiceUrl");
        Mockito.when(anmfBelongToCustomerService.anmfBelongsToCustomer(123456789, "jwtToken", "customerServiceUrl", AnmfRegion.A)).thenReturn(true);
        SimulationListInput simulationListInput = TestDataCreator.generateDefaultSimulationControllerRequest();
        Mockito.when(simulationService.getSimulations(123456789, simulationListInput, "jwtToken")).thenReturn(TestDataCreator.generateDefaultSimulationServiceResponse());

        ResponseEntity<SimulationControllerResponse> simulationERCControllerResponseResponseEntity = simulationController.simulate(simulationListInput, 123456789, "jwtToken");

        assertEquals(HttpStatus.OK, simulationERCControllerResponseResponseEntity.getStatusCode());
        assertEquals("ok", Objects.requireNonNull(simulationERCControllerResponseResponseEntity.getBody()).getInfo().getStatus());
        assertEquals("", simulationERCControllerResponseResponseEntity.getBody().getInfo().getCode());
        assertEquals("Data found", simulationERCControllerResponseResponseEntity.getBody().getInfo().getMessage());

        assertEquals(2, simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().size());

        assertEquals(6974492, simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(0).getSimulationId());
        assertEquals(new BigDecimal("3077.43"), simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(0).getDiffInterest());
        assertEquals("3R", simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(0).getOutputLoanDataList().get(0).getLoanScheme());
        assertEquals(3, simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(0).getOutputLoanDataList().get(0).getApplicationSequenceNumber());
        assertEquals(new BigDecimal("100.00"), simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(0).getOutputLoanDataList().get(0).getLoanOverpaymentAmount());
        assertEquals(new BigDecimal("107.93"), simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(0).getOutputLoanDataList().get(0).getLoanTotalPaymentAmount());
        assertEquals("07/10/2042", simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(0).getOutputLoanDataList().get(0).getCurrentMaturityDate());
        assertEquals(new BigDecimal("3077.43"), simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(0).getOutputLoanDataList().get(0).getDiffLoanInterestSimulation());
        assertEquals(new BigDecimal("7.93"), simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(0).getOutputLoanDataList().get(0).getLoanERC());
        assertEquals(new BigDecimal("216.95"), simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(0).getOutputLoanDataList().get(0).getCurrentMonthlyPayment());
        assertEquals(new BigDecimal("0.00"), simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(0).getOutputLoanDataList().get(0).getDiffMonthlyPayment());
        assertEquals("3 years, 1 month", simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(0).getOutputLoanDataList().get(0).getDiffMortgageTerm());
        assertEquals(new BigDecimal("216.97"), simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(0).getOutputLoanDataList().get(0).getFirstPaymentAfterOverpayment());
        assertEquals(new BigDecimal("216.96"), simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(0).getOutputLoanDataList().get(0).getSecondPaymentAfterOverpayment());
        assertNotNull(simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(0).getOutputLoanDataList().get(0).getNewMortgageTerm());
        assertNotEquals("", simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(0).getOutputLoanDataList().get(0).getNewMortgageTerm());
        assertEquals("07/09/2039", simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(0).getOutputLoanDataList().get(0).getSimulationMaturityDate());
        assertEquals(new BigDecimal("216.95"), simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(0).getOutputLoanDataList().get(0).getSimulationMonthlyPayment());
        assertEquals(new BigDecimal("11754.02"), simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(0).getOutputLoanDataList().get(0).getLoanInterestBeforeSimulation());
        assertEquals(new BigDecimal("8676.59"), simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(0).getOutputLoanDataList().get(0).getLoanInterestAfterSimulation());

        assertEquals(6974492, simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(1).getSimulationId());
        assertEquals(new BigDecimal("1410.88"), simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(1).getDiffInterest());
        assertEquals("3R", simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(1).getOutputLoanDataList().get(0).getLoanScheme());
        assertEquals(3, simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(1).getOutputLoanDataList().get(0).getApplicationSequenceNumber());
        assertEquals(new BigDecimal("192.07"), simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(1).getOutputLoanDataList().get(0).getLoanOverpaymentAmount());
        assertEquals(new BigDecimal("200.00"), simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(1).getOutputLoanDataList().get(0).getLoanTotalPaymentAmount());
        assertEquals("07/10/2042", simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(1).getOutputLoanDataList().get(0).getCurrentMaturityDate());
        assertEquals(new BigDecimal("1410.88"), simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(1).getOutputLoanDataList().get(0).getDiffLoanInterestSimulation());
        assertEquals(new BigDecimal("7.93"), simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(1).getOutputLoanDataList().get(0).getLoanERC());
        assertEquals(new BigDecimal("216.95"), simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(1).getOutputLoanDataList().get(0).getCurrentMonthlyPayment());
        assertEquals(new BigDecimal("26.16"), simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(1).getOutputLoanDataList().get(0).getDiffMonthlyPayment());
        assertEquals("0 years, 0 months", simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(1).getOutputLoanDataList().get(0).getDiffMortgageTerm());
        assertEquals(new BigDecimal("196.97"), simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(1).getOutputLoanDataList().get(0).getFirstPaymentAfterOverpayment());
        assertEquals(new BigDecimal("190.79"), simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(1).getOutputLoanDataList().get(0).getSecondPaymentAfterOverpayment());
        assertNotNull(simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(1).getOutputLoanDataList().get(0).getNewMortgageTerm());
        assertNotEquals("", simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(1).getOutputLoanDataList().get(0).getNewMortgageTerm());
        assertEquals("07/10/2042", simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(1).getOutputLoanDataList().get(0).getSimulationMaturityDate());
        assertEquals(new BigDecimal("190.79"), simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(1).getOutputLoanDataList().get(0).getSimulationMonthlyPayment());
        assertEquals(new BigDecimal("11754.02"), simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(1).getOutputLoanDataList().get(0).getLoanInterestBeforeSimulation());
        assertEquals(new BigDecimal("10343.14"), simulationERCControllerResponseResponseEntity.getBody().getDataResponse().getSimulationResponseList().get(1).getOutputLoanDataList().get(0).getLoanInterestAfterSimulation());
    }

    @Test
    void testOperativeSecurityOk() throws IOException, GeneralException {
        Mockito.when(anmfConfig.isOperativeSecurity()).thenReturn(true);
        Mockito.when(anmfConfig.getAnmfCustomerServiceUrl()).thenReturn("customerServiceUrl");
        Mockito.when(anmfBelongToCustomerService.anmfBelongsToCustomer(123456789, "jwtToken", "customerServiceUrl", AnmfRegion.A)).thenReturn(true);

        simulationController.simulate(TestDataCreator.generateDefaultSimulationControllerRequest(), 123456789, "jwtToken");
    }

    @Test
    void testOperativeSecurityKo() throws ConnectionException, ValidationsException {
        Mockito.when(anmfConfig.isOperativeSecurity()).thenReturn(true);
        Mockito.when(anmfConfig.getAnmfCustomerServiceUrl()).thenReturn("customerServiceUrl");
        Mockito.when(anmfBelongToCustomerService.anmfBelongsToCustomer(123456789, "jwtToken", "customerServiceUrl", AnmfRegion.A)).thenReturn(false);

        assertThrows(OperativeSecurityException.class, () -> simulationController.simulate(TestDataCreator.generateDefaultSimulationControllerRequest(), 123456789, "jwtToken"));
    }

    @Test
    void testOperativeSecurityExc() throws ConnectionException, ValidationsException {
        Mockito.when(anmfConfig.isOperativeSecurity()).thenReturn(true);
        Mockito.when(anmfConfig.getAnmfCustomerServiceUrl()).thenReturn("customerServiceUrl");
        Mockito.when(anmfBelongToCustomerService.anmfBelongsToCustomer(123456789, "jwtToken", "customerServiceUrl", AnmfRegion.A)).thenThrow(ConnectionException.class);

        assertThrows(OperativeSecurityException.class, () -> simulationController.simulate(TestDataCreator.generateDefaultSimulationControllerRequest(), 123456789, "jwtToken"));
    }
}
