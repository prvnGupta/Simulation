package com.santanderuk.corinthian.hub.simulations.functional;

import com.jayway.restassured.response.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

import static com.jayway.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ActiveProfiles("health")
public class HealthFunctionalTest extends FunctionalTest {

    String healthUrl;
    String healthZUrl;

    @BeforeEach
    public void setup() {
        healthUrl = String.format("http://localhost:%s/simulations/health", serverPort);
        healthZUrl = String.format("http://localhost:%s/simulations/healthz", serverPort);
    }

    @Test
    public void customHealthCheckReturnsUp() {

        Response res =
                given().
                        when().
                        get(healthUrl).
                        then().
                        statusCode(200).extract().response();

        assertEquals("Up", res.asString());
    }

    @Test
    public void customHealthZCheckReturnsUp() {

        Response res =
                given().
                        when().
                        get(healthZUrl).
                        then().
                        statusCode(200).extract().response();

        assertEquals("Up", res.asString());
    }

}
