package com.santanderuk.corinthian.hub.simulations.api.simulation.services;

import com.santanderuk.corinthian.hub.simulations.TestDataCreator;
import com.santanderuk.corinthian.hub.simulations.api.simulation.model.SimulationListInput;
import com.santanderuk.corinthian.hub.simulations.config.AnmfConfig;
import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.ANMFSimulationRequest;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SimulationRequestMapperTest {
    SimulationRequestMapper simulationRequestMapper;
    @Mock
    private AnmfConfig anmfConfig;

    @BeforeEach
    void setUp() {
        simulationRequestMapper = new SimulationRequestMapper(anmfConfig);
    }

    @Test
    void testException() throws IOException {

        SimulationListInput simulationListInput = TestDataCreator.generateDefaultSimulationControllerRequest();
        simulationListInput.getSimulationListInput().get(0).getSimulationLoanDetails().get(0).setLoanOverpaymentAmount(null);
        assertThrows(GeneralException.class, () -> simulationRequestMapper.mapInput(123456789, simulationListInput, TestDataCreator.createDefaultBdpCustomer(), "ldapuid"));

    }

    @Test
    void testSimulationInputMapper() throws IOException, GeneralException {

        when(anmfConfig.getCallingApplication()).thenReturn("OVERPAYMENTS");
        when(anmfConfig.getChannelType()).thenReturn("5");
        when(anmfConfig.getSimulationVersion()).thenReturn(1);
        when(anmfConfig.getUserId()).thenReturn("OVPDIGU");

        List<ANMFSimulationRequest> simulationRequests = simulationRequestMapper.mapInput(123456789, TestDataCreator.generateDefaultSimulationControllerRequest(), TestDataCreator.createDefaultBdpCustomer(), "ldapuid");
        assertEquals(2, simulationRequests.size());

        assertEquals(0, simulationRequests.get(0).getOverpaymentSimulationRequest().getInputStruc().getISimulationId());
        assertEquals(123456789, simulationRequests.get(0).getOverpaymentSimulationRequest().getInputStruc().getIMortAccNo());
        assertEquals("5", simulationRequests.get(0).getOverpaymentSimulationRequest().getInputStruc().getIChanTypeCd());
        assertEquals("OVERPAYMENTS", simulationRequests.get(0).getOverpaymentSimulationRequest().getInputStruc().getICallingAppl());
        assertEquals("O", simulationRequests.get(0).getOverpaymentSimulationRequest().getInputStruc().getIErcCollOpt());
        assertEquals(0, simulationRequests.get(0).getOverpaymentSimulationRequest().getInputStruc().getIOriginalSimulationId());
        assertEquals(1, simulationRequests.get(0).getOverpaymentSimulationRequest().getInputStruc().getISimVersion());
        assertEquals("", simulationRequests.get(0).getOverpaymentSimulationRequest().getInputStruc().getIPaymentData().getISimPayMeth());
        assertEquals(new BigDecimal("100.00"), simulationRequests.get(0).getOverpaymentSimulationRequest().getInputStruc().getITotOvpAmount());
        assertEquals(123456789, simulationRequests.get(0).getOverpaymentSimulationRequest().getInputStruc().getIBdpNumber());
        assertEquals("F", simulationRequests.get(0).getOverpaymentSimulationRequest().getInputStruc().getIBdpType());
        assertEquals("O", simulationRequests.get(0).getOverpaymentSimulationRequest().getInputStruc().getIDistriType());
        assertEquals("", simulationRequests.get(0).getOverpaymentSimulationRequest().getInputStruc().getIErcAllowImp());
        assertEquals("", simulationRequests.get(0).getOverpaymentSimulationRequest().getInputStruc().getIKfiRefNo());
        assertEquals(10, simulationRequests.get(0).getOverpaymentSimulationRequest().getInputStruc().getIOvpDate().length());
        assertEquals("ldapuid", simulationRequests.get(0).getOverpaymentSimulationRequest().getInputStruc().getIStaffId());
        assertEquals("OVPDIGU", simulationRequests.get(0).getOverpaymentSimulationRequest().getInputStruc().getIUserId());


        assertEquals("3R", simulationRequests.get(0).getOverpaymentSimulationRequest().getInputStruc().getILoanData().get(0).getILoanSch());
        assertEquals(3, simulationRequests.get(0).getOverpaymentSimulationRequest().getInputStruc().getILoanData().get(0).getIApplSeqNo());
        assertEquals("M", simulationRequests.get(0).getOverpaymentSimulationRequest().getInputStruc().getILoanData().get(0).getIChangeType());
        assertEquals("N", simulationRequests.get(0).getOverpaymentSimulationRequest().getInputStruc().getILoanData().get(0).getIErcWaiver());
        assertEquals("", simulationRequests.get(0).getOverpaymentSimulationRequest().getInputStruc().getILoanData().get(0).getIErcWaiverRsn());
        assertEquals(new BigDecimal("100.00"), simulationRequests.get(0).getOverpaymentSimulationRequest().getInputStruc().getILoanData().get(0).getILnOvpAmount());


        assertEquals(0, simulationRequests.get(1).getOverpaymentSimulationRequest().getInputStruc().getISimulationId());
        assertEquals(123456789, simulationRequests.get(1).getOverpaymentSimulationRequest().getInputStruc().getIMortAccNo());
        assertEquals("5", simulationRequests.get(1).getOverpaymentSimulationRequest().getInputStruc().getIChanTypeCd());
        assertEquals("OVERPAYMENTS", simulationRequests.get(1).getOverpaymentSimulationRequest().getInputStruc().getICallingAppl());
        assertEquals("I", simulationRequests.get(1).getOverpaymentSimulationRequest().getInputStruc().getIErcCollOpt());
        assertEquals(0, simulationRequests.get(1).getOverpaymentSimulationRequest().getInputStruc().getIOriginalSimulationId());
        assertEquals(1, simulationRequests.get(1).getOverpaymentSimulationRequest().getInputStruc().getISimVersion());
        assertEquals("", simulationRequests.get(1).getOverpaymentSimulationRequest().getInputStruc().getIPaymentData().getISimPayMeth());
        assertEquals(new BigDecimal("500.00"), simulationRequests.get(1).getOverpaymentSimulationRequest().getInputStruc().getITotOvpAmount());
        assertEquals(123456789, simulationRequests.get(1).getOverpaymentSimulationRequest().getInputStruc().getIBdpNumber());
        assertEquals("F", simulationRequests.get(1).getOverpaymentSimulationRequest().getInputStruc().getIBdpType());
        assertEquals("O", simulationRequests.get(1).getOverpaymentSimulationRequest().getInputStruc().getIDistriType());
        assertEquals("", simulationRequests.get(1).getOverpaymentSimulationRequest().getInputStruc().getIErcAllowImp());
        assertEquals("", simulationRequests.get(1).getOverpaymentSimulationRequest().getInputStruc().getIKfiRefNo());
        assertEquals(10, simulationRequests.get(1).getOverpaymentSimulationRequest().getInputStruc().getIOvpDate().length());
        assertEquals("ldapuid", simulationRequests.get(1).getOverpaymentSimulationRequest().getInputStruc().getIStaffId());
        assertEquals("OVPDIGU", simulationRequests.get(1).getOverpaymentSimulationRequest().getInputStruc().getIUserId());


        assertEquals("3T", simulationRequests.get(1).getOverpaymentSimulationRequest().getInputStruc().getILoanData().get(0).getILoanSch());
        assertEquals(1, simulationRequests.get(1).getOverpaymentSimulationRequest().getInputStruc().getILoanData().get(0).getIApplSeqNo());
        assertEquals("T", simulationRequests.get(1).getOverpaymentSimulationRequest().getInputStruc().getILoanData().get(0).getIChangeType());
        assertEquals("N", simulationRequests.get(1).getOverpaymentSimulationRequest().getInputStruc().getILoanData().get(0).getIErcWaiver());
        assertEquals("", simulationRequests.get(1).getOverpaymentSimulationRequest().getInputStruc().getILoanData().get(0).getIErcWaiverRsn());
        assertEquals(new BigDecimal("200.00"), simulationRequests.get(1).getOverpaymentSimulationRequest().getInputStruc().getILoanData().get(0).getILnOvpAmount());

        assertEquals("3T", simulationRequests.get(1).getOverpaymentSimulationRequest().getInputStruc().getILoanData().get(1).getILoanSch());
        assertEquals(2, simulationRequests.get(1).getOverpaymentSimulationRequest().getInputStruc().getILoanData().get(1).getIApplSeqNo());
        assertEquals("T", simulationRequests.get(1).getOverpaymentSimulationRequest().getInputStruc().getILoanData().get(1).getIChangeType());
        assertEquals("N", simulationRequests.get(1).getOverpaymentSimulationRequest().getInputStruc().getILoanData().get(1).getIErcWaiver());
        assertEquals("", simulationRequests.get(1).getOverpaymentSimulationRequest().getInputStruc().getILoanData().get(1).getIErcWaiverRsn());
        assertEquals(new BigDecimal("300.00"), simulationRequests.get(1).getOverpaymentSimulationRequest().getInputStruc().getILoanData().get(1).getILnOvpAmount());


    }
}
