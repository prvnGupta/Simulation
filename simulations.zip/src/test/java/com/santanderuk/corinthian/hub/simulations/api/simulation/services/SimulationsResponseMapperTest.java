package com.santanderuk.corinthian.hub.simulations.api.simulation.services;

import com.santanderuk.corinthian.hub.simulations.TestDataCreator;
import com.santanderuk.corinthian.hub.simulations.api.simulation.model.DataResponse;
import com.santanderuk.corinthian.hub.simulations.api.simulation.model.SimulationResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class SimulationsResponseMapperTest {

    private SimulationsResponseMapper simulationsResponseMapper;

    @BeforeEach
    void setUp() {
        simulationsResponseMapper = new SimulationsResponseMapper();
    }

    @Test
    void testHappyPath() throws IOException {
        DataResponse dataResponse = simulationsResponseMapper.createResponse(TestDataCreator.generateListOfSimulationResponses(), TestDataCreator.generateListOfSimulationRequests());

        assertEquals(3, dataResponse.getSimulationResponseList().size());

        var firstSimulation = dataResponse.getSimulationResponseList().get(0);
        assertEquals(25581, firstSimulation.getSimulationId());
        assertEquals(BigDecimal.valueOf(500.0), firstSimulation.getTotalOverpaymentAmount());
        assertEquals(BigDecimal.valueOf(5000.0), firstSimulation.getTotalERC());
        assertEquals(BigDecimal.valueOf(2000.0), firstSimulation.getTotalPayment());
        assertEquals(BigDecimal.valueOf(1500.0), firstSimulation.getTotalAccountSimulationMonthlyPayment());
        assertEquals(BigDecimal.valueOf(11754.02), firstSimulation.getTotalInterestBeforeSimulation());
        assertEquals(BigDecimal.valueOf(10343.14), firstSimulation.getTotalInterestAfterSimulation());
        assertEquals(BigDecimal.valueOf(1410.88), firstSimulation.getDiffInterest());
        assertTrue(firstSimulation.isTotalInterestChanged());
        assertEquals(BigDecimal.valueOf(0.0), firstSimulation.getOutstandingBalance());
        assertEquals(BigDecimal.valueOf(7889.52), firstSimulation.getTotalNextMonthlyPayment());
        assertEquals(BigDecimal.valueOf(7886.58), firstSimulation.getTotalSecondMonthlyPayment());
        assertEquals(BigDecimal.valueOf(0.94), firstSimulation.getTotalMonthlyPaymentReduction());
        assertEquals(0, firstSimulation.getTotalTermReduction());

        assertEquals(1, firstSimulation.getOutputLoanDataList().size());
        assertEquals("3R", firstSimulation.getOutputLoanDataList().get(0).getLoanScheme());
        assertEquals(2, firstSimulation.getOutputLoanDataList().get(0).getApplicationSequenceNumber());
        assertEquals(BigDecimal.valueOf(200.0), firstSimulation.getOutputLoanDataList().get(0).getLoanOverpaymentAmount());
        assertEquals(BigDecimal.valueOf(200.0), firstSimulation.getOutputLoanDataList().get(0).getLoanTotalPaymentAmount());
        assertEquals(BigDecimal.valueOf(0.0), firstSimulation.getOutputLoanDataList().get(0).getLoanERC());
        assertEquals(BigDecimal.valueOf(0.0), firstSimulation.getOutputLoanDataList().get(0).getCurrentMonthlyPayment());
        assertEquals(BigDecimal.valueOf(0.0), firstSimulation.getOutputLoanDataList().get(0).getSimulationMonthlyPayment());
        assertEquals("28/10/2034", firstSimulation.getOutputLoanDataList().get(0).getCurrentMaturityDate());
        assertEquals("28/10/2034", firstSimulation.getOutputLoanDataList().get(0).getSimulationMaturityDate());
        assertTrue(firstSimulation.getOutputLoanDataList().get(0).getNewMortgageTerm().contains("year"));
        assertTrue(firstSimulation.getOutputLoanDataList().get(0).getNewMortgageTerm().contains("month"));
        assertEquals("0 years, 0 months", firstSimulation.getOutputLoanDataList().get(0).getDiffMortgageTerm());
        assertFalse(firstSimulation.getOutputLoanDataList().get(0).isMortgageTermChanged());
        assertEquals(BigDecimal.valueOf(0.94), firstSimulation.getOutputLoanDataList().get(0).getDiffMonthlyPayment());
        assertTrue(firstSimulation.getOutputLoanDataList().get(0).isMonthlyPaymentChanged());
        assertEquals(BigDecimal.valueOf(11754.02), firstSimulation.getOutputLoanDataList().get(0).getLoanInterestBeforeSimulation());
        assertEquals(BigDecimal.valueOf(10343.14), firstSimulation.getOutputLoanDataList().get(0).getLoanInterestAfterSimulation());
        assertEquals(BigDecimal.valueOf(1410.88), firstSimulation.getOutputLoanDataList().get(0).getDiffLoanInterestSimulation());
        assertTrue(firstSimulation.getOutputLoanDataList().get(0).isLoanInterestChanged());
        assertEquals(BigDecimal.valueOf(7889.52), firstSimulation.getOutputLoanDataList().get(0).getFirstPaymentAfterOverpayment());
        assertEquals(BigDecimal.valueOf(7886.58), firstSimulation.getOutputLoanDataList().get(0).getSecondPaymentAfterOverpayment());


        SimulationResponse secondSimulation = dataResponse.getSimulationResponseList().get(1);
        assertEquals(6974484, secondSimulation.getSimulationId());
        assertEquals(BigDecimal.valueOf(4992.07), secondSimulation.getTotalOverpaymentAmount());
        assertEquals(BigDecimal.valueOf(7.93), secondSimulation.getTotalERC());
        assertEquals(BigDecimal.valueOf(5000), secondSimulation.getTotalPayment());
        assertEquals(BigDecimal.valueOf(190.79), secondSimulation.getTotalAccountSimulationMonthlyPayment());
        assertEquals(BigDecimal.valueOf(11754.02), secondSimulation.getTotalInterestBeforeSimulation());
        assertEquals(BigDecimal.valueOf(10343.14), secondSimulation.getTotalInterestAfterSimulation());
        assertEquals(BigDecimal.valueOf(1410.88), secondSimulation.getDiffInterest());
        assertTrue(secondSimulation.isTotalInterestChanged());
        assertEquals(BigDecimal.valueOf(36410.89), secondSimulation.getOutstandingBalance());
        assertEquals(BigDecimal.valueOf(7889.52), secondSimulation.getTotalNextMonthlyPayment());
        assertEquals(BigDecimal.valueOf(7886.58), secondSimulation.getTotalSecondMonthlyPayment());
        assertEquals(BigDecimal.valueOf(0.94), secondSimulation.getTotalMonthlyPaymentReduction());
        assertEquals(0, secondSimulation.getTotalTermReduction());

        assertEquals(1, secondSimulation.getOutputLoanDataList().size());
        assertEquals("3R", secondSimulation.getOutputLoanDataList().get(0).getLoanScheme());
        assertEquals(2, secondSimulation.getOutputLoanDataList().get(0).getApplicationSequenceNumber());
        assertEquals(BigDecimal.valueOf(242.07), secondSimulation.getOutputLoanDataList().get(0).getLoanOverpaymentAmount());
        assertEquals(BigDecimal.valueOf(250.0), secondSimulation.getOutputLoanDataList().get(0).getLoanTotalPaymentAmount());
        assertEquals(BigDecimal.valueOf(7.93), secondSimulation.getOutputLoanDataList().get(0).getLoanERC());
        assertEquals(BigDecimal.valueOf(216.95), secondSimulation.getOutputLoanDataList().get(0).getCurrentMonthlyPayment());
        assertEquals(BigDecimal.valueOf(190.79), secondSimulation.getOutputLoanDataList().get(0).getSimulationMonthlyPayment());
        assertEquals("07/10/2042", secondSimulation.getOutputLoanDataList().get(0).getCurrentMaturityDate());
        assertEquals("07/10/2042", secondSimulation.getOutputLoanDataList().get(0).getSimulationMaturityDate());
        assertTrue(secondSimulation.getOutputLoanDataList().get(0).getNewMortgageTerm().contains("year"));
        assertTrue(secondSimulation.getOutputLoanDataList().get(0).getNewMortgageTerm().contains("month"));
        assertEquals("0 years, 0 months", secondSimulation.getOutputLoanDataList().get(0).getDiffMortgageTerm());
        assertFalse(secondSimulation.getOutputLoanDataList().get(0).isMortgageTermChanged());
        assertEquals(BigDecimal.valueOf(0.94), secondSimulation.getOutputLoanDataList().get(0).getDiffMonthlyPayment());
        assertTrue(secondSimulation.getOutputLoanDataList().get(0).isMonthlyPaymentChanged());
        assertEquals(BigDecimal.valueOf(11754.02), secondSimulation.getOutputLoanDataList().get(0).getLoanInterestBeforeSimulation());
        assertEquals(BigDecimal.valueOf(10343.14), secondSimulation.getOutputLoanDataList().get(0).getLoanInterestAfterSimulation());
        assertEquals(BigDecimal.valueOf(83.87), secondSimulation.getOutputLoanDataList().get(0).getDiffLoanInterestSimulation());
        assertTrue(secondSimulation.getOutputLoanDataList().get(0).isLoanInterestChanged());
        assertEquals(BigDecimal.valueOf(7889.52), secondSimulation.getOutputLoanDataList().get(0).getFirstPaymentAfterOverpayment());
        assertEquals(BigDecimal.valueOf(7886.58), secondSimulation.getOutputLoanDataList().get(0).getSecondPaymentAfterOverpayment());


        SimulationResponse thirdSimulation = dataResponse.getSimulationResponseList().get(2);
        assertEquals(6974484, thirdSimulation.getSimulationId());
        assertEquals(BigDecimal.valueOf(5000), thirdSimulation.getTotalOverpaymentAmount());
        assertEquals(BigDecimal.valueOf(8.01), thirdSimulation.getTotalERC());
        assertEquals(BigDecimal.valueOf(5008.01), thirdSimulation.getTotalPayment());
        assertEquals(BigDecimal.valueOf(190.75), thirdSimulation.getTotalAccountSimulationMonthlyPayment());
        assertEquals(BigDecimal.valueOf(11754.02), thirdSimulation.getTotalInterestBeforeSimulation());
        assertEquals(BigDecimal.valueOf(10340.79), thirdSimulation.getTotalInterestAfterSimulation());
        assertEquals(BigDecimal.valueOf(1410.88), thirdSimulation.getDiffInterest());
        assertTrue(thirdSimulation.isTotalInterestChanged());
        assertEquals(BigDecimal.valueOf(36402.96), thirdSimulation.getOutstandingBalance());
        assertEquals(BigDecimal.valueOf(7889.52), thirdSimulation.getTotalNextMonthlyPayment());
        assertEquals(BigDecimal.valueOf(7886.58), thirdSimulation.getTotalSecondMonthlyPayment());
        assertEquals(BigDecimal.valueOf(0.94), thirdSimulation.getTotalMonthlyPaymentReduction());
        assertEquals(0, thirdSimulation.getTotalTermReduction());

        assertEquals(1, thirdSimulation.getOutputLoanDataList().size());
        assertEquals("3R", thirdSimulation.getOutputLoanDataList().get(0).getLoanScheme());
        assertEquals(2, thirdSimulation.getOutputLoanDataList().get(0).getApplicationSequenceNumber());
        assertEquals(BigDecimal.valueOf(300.0), thirdSimulation.getOutputLoanDataList().get(0).getLoanOverpaymentAmount());
        assertEquals(BigDecimal.valueOf(308.01), thirdSimulation.getOutputLoanDataList().get(0).getLoanTotalPaymentAmount());
        assertEquals(BigDecimal.valueOf(8.01), thirdSimulation.getOutputLoanDataList().get(0).getLoanERC());
        assertEquals(BigDecimal.valueOf(216.95), thirdSimulation.getOutputLoanDataList().get(0).getCurrentMonthlyPayment());
        assertEquals(BigDecimal.valueOf(190.75), thirdSimulation.getOutputLoanDataList().get(0).getSimulationMonthlyPayment());
        assertEquals("07/10/2042", thirdSimulation.getOutputLoanDataList().get(0).getCurrentMaturityDate());
        assertEquals("07/10/2042", thirdSimulation.getOutputLoanDataList().get(0).getSimulationMaturityDate());
        assertTrue(thirdSimulation.getOutputLoanDataList().get(0).getNewMortgageTerm().contains("year"));
        assertTrue(thirdSimulation.getOutputLoanDataList().get(0).getNewMortgageTerm().contains("month"));
        assertEquals("0 years, 0 months", thirdSimulation.getOutputLoanDataList().get(0).getDiffMortgageTerm());
        assertFalse(thirdSimulation.getOutputLoanDataList().get(0).isMortgageTermChanged());
        assertEquals(BigDecimal.valueOf(0.94), thirdSimulation.getOutputLoanDataList().get(0).getDiffMonthlyPayment());
        assertTrue(thirdSimulation.getOutputLoanDataList().get(0).isMonthlyPaymentChanged());
        assertEquals(BigDecimal.valueOf(11754.02), thirdSimulation.getOutputLoanDataList().get(0).getLoanInterestBeforeSimulation());
        assertEquals(BigDecimal.valueOf(10340.79), thirdSimulation.getOutputLoanDataList().get(0).getLoanInterestAfterSimulation());
        assertEquals(BigDecimal.valueOf(83.87), thirdSimulation.getOutputLoanDataList().get(0).getDiffLoanInterestSimulation());
        assertTrue(thirdSimulation.getOutputLoanDataList().get(0).isLoanInterestChanged());
        assertEquals(BigDecimal.valueOf(7889.52), thirdSimulation.getOutputLoanDataList().get(0).getFirstPaymentAfterOverpayment());
        assertEquals(BigDecimal.valueOf(7886.58), thirdSimulation.getOutputLoanDataList().get(0).getSecondPaymentAfterOverpayment());


    }


    @Test
    void testHappyPathMultiLoan() throws IOException {
        DataResponse dataResponse = simulationsResponseMapper.createResponse(TestDataCreator.generateListOfSimulationResponsesMultiLoan(), TestDataCreator.generateListOfSimulationRequestsMultiLoan());

        assertEquals(2, dataResponse.getSimulationResponseList().size());
        SimulationResponse firstSimulation = dataResponse.getSimulationResponseList().get(0);
        assertEquals(200607583, firstSimulation.getSimulationId());
        assertEquals(BigDecimal.valueOf(6000), firstSimulation.getTotalOverpaymentAmount());
        assertEquals(BigDecimal.valueOf(13.74), firstSimulation.getTotalERC());
        assertEquals(BigDecimal.valueOf(6013.74), firstSimulation.getTotalPayment());
        assertEquals(BigDecimal.valueOf(709.56), firstSimulation.getTotalAccountSimulationMonthlyPayment());
        assertEquals(BigDecimal.valueOf(3066.07), firstSimulation.getTotalInterestBeforeSimulation());
        assertEquals(BigDecimal.valueOf(2452.17), firstSimulation.getTotalInterestAfterSimulation());
        assertEquals(BigDecimal.valueOf(613.9), firstSimulation.getDiffInterest());
        assertTrue(firstSimulation.isTotalInterestChanged());
        assertEquals(BigDecimal.valueOf(45644.22), firstSimulation.getOutstandingBalance());
        assertEquals(BigDecimal.valueOf(709.56), firstSimulation.getTotalNextMonthlyPayment());
        assertEquals(BigDecimal.valueOf(709.55), firstSimulation.getTotalSecondMonthlyPayment());
        assertEquals(BigDecimal.valueOf(0), firstSimulation.getTotalMonthlyPaymentReduction());
        assertEquals(44, firstSimulation.getTotalTermReduction());

        assertEquals(2, firstSimulation.getOutputLoanDataList().size());
        assertEquals("3R", firstSimulation.getOutputLoanDataList().get(0).getLoanScheme());
        assertEquals(7, firstSimulation.getOutputLoanDataList().get(0).getApplicationSequenceNumber());
        assertEquals(BigDecimal.valueOf(3000), firstSimulation.getOutputLoanDataList().get(0).getLoanOverpaymentAmount());
        assertEquals(BigDecimal.valueOf(3000), firstSimulation.getOutputLoanDataList().get(0).getLoanTotalPaymentAmount());
        assertEquals(BigDecimal.valueOf(0), firstSimulation.getOutputLoanDataList().get(0).getLoanERC());
        assertEquals(BigDecimal.valueOf(636.67), firstSimulation.getOutputLoanDataList().get(0).getCurrentMonthlyPayment());
        assertEquals(BigDecimal.valueOf(636.67), firstSimulation.getOutputLoanDataList().get(0).getSimulationMonthlyPayment());
        assertEquals("02/11/2029", firstSimulation.getOutputLoanDataList().get(0).getCurrentMaturityDate());
        assertEquals("02/06/2029", firstSimulation.getOutputLoanDataList().get(0).getSimulationMaturityDate());
        assertTrue(firstSimulation.getOutputLoanDataList().get(0).getNewMortgageTerm().contains("year"));
        assertTrue(firstSimulation.getOutputLoanDataList().get(0).getNewMortgageTerm().contains("month"));
        assertEquals("0 years, 5 months", firstSimulation.getOutputLoanDataList().get(0).getDiffMortgageTerm());
        assertTrue(firstSimulation.getOutputLoanDataList().get(0).isMortgageTermChanged());
        assertEquals(BigDecimal.valueOf(0), firstSimulation.getOutputLoanDataList().get(0).getDiffMonthlyPayment());
        assertFalse(firstSimulation.getOutputLoanDataList().get(0).isMonthlyPaymentChanged());
        assertEquals(BigDecimal.valueOf(2743.63), firstSimulation.getOutputLoanDataList().get(0).getLoanInterestBeforeSimulation());
        assertEquals(BigDecimal.valueOf(2390.36), firstSimulation.getOutputLoanDataList().get(0).getLoanInterestAfterSimulation());
        assertEquals(BigDecimal.valueOf(353.27), firstSimulation.getOutputLoanDataList().get(0).getDiffLoanInterestSimulation());
        assertTrue(firstSimulation.getOutputLoanDataList().get(0).isLoanInterestChanged());
        assertEquals(BigDecimal.valueOf(636.67), firstSimulation.getOutputLoanDataList().get(0).getFirstPaymentAfterOverpayment());
        assertEquals(BigDecimal.valueOf(636.67), firstSimulation.getOutputLoanDataList().get(0).getSecondPaymentAfterOverpayment());

        assertEquals("3R", firstSimulation.getOutputLoanDataList().get(1).getLoanScheme());
        assertEquals(8, firstSimulation.getOutputLoanDataList().get(1).getApplicationSequenceNumber());
        assertEquals(BigDecimal.valueOf(3000), firstSimulation.getOutputLoanDataList().get(1).getLoanOverpaymentAmount());
        assertEquals(BigDecimal.valueOf(3013.74), firstSimulation.getOutputLoanDataList().get(1).getLoanTotalPaymentAmount());
        assertEquals(BigDecimal.valueOf(13.74), firstSimulation.getOutputLoanDataList().get(1).getLoanERC());
        assertEquals(BigDecimal.valueOf(72.89), firstSimulation.getOutputLoanDataList().get(1).getCurrentMonthlyPayment());
        assertEquals(BigDecimal.valueOf(72.89), firstSimulation.getOutputLoanDataList().get(1).getSimulationMonthlyPayment());
        assertEquals("02/12/2029", firstSimulation.getOutputLoanDataList().get(1).getCurrentMaturityDate());
        assertEquals("02/04/2026", firstSimulation.getOutputLoanDataList().get(1).getSimulationMaturityDate());
        assertTrue(firstSimulation.getOutputLoanDataList().get(1).getNewMortgageTerm().contains("year"));
        assertTrue(firstSimulation.getOutputLoanDataList().get(1).getNewMortgageTerm().contains("month"));
        assertEquals("3 years, 8 months", firstSimulation.getOutputLoanDataList().get(1).getDiffMortgageTerm());
        assertTrue(firstSimulation.getOutputLoanDataList().get(1).isMortgageTermChanged());
        assertEquals(BigDecimal.valueOf(0), firstSimulation.getOutputLoanDataList().get(1).getDiffMonthlyPayment());
        assertFalse(firstSimulation.getOutputLoanDataList().get(1).isMonthlyPaymentChanged());
        assertEquals(BigDecimal.valueOf(322.44), firstSimulation.getOutputLoanDataList().get(1).getLoanInterestBeforeSimulation());
        assertEquals(BigDecimal.valueOf(61.81), firstSimulation.getOutputLoanDataList().get(1).getLoanInterestAfterSimulation());
        assertEquals(BigDecimal.valueOf(260.63), firstSimulation.getOutputLoanDataList().get(1).getDiffLoanInterestSimulation());
        assertTrue(firstSimulation.getOutputLoanDataList().get(1).isLoanInterestChanged());
        assertEquals(BigDecimal.valueOf(72.89), firstSimulation.getOutputLoanDataList().get(1).getFirstPaymentAfterOverpayment());
        assertEquals(BigDecimal.valueOf(72.88), firstSimulation.getOutputLoanDataList().get(1).getSecondPaymentAfterOverpayment());

        SimulationResponse secondSimulation = dataResponse.getSimulationResponseList().get(1);
        assertEquals(200607582, secondSimulation.getSimulationId());
        assertEquals(BigDecimal.valueOf(5986.66), secondSimulation.getTotalOverpaymentAmount());
        assertEquals(BigDecimal.valueOf(13.34), secondSimulation.getTotalERC());
        assertEquals(BigDecimal.valueOf(6000), secondSimulation.getTotalPayment());
        assertEquals(BigDecimal.valueOf(709.56), secondSimulation.getTotalAccountSimulationMonthlyPayment());
        assertEquals(BigDecimal.valueOf(3066.07), secondSimulation.getTotalInterestBeforeSimulation());
        assertEquals(BigDecimal.valueOf(2452.87), secondSimulation.getTotalInterestAfterSimulation());
        assertEquals(BigDecimal.valueOf(613.2), secondSimulation.getDiffInterest());
        assertTrue(secondSimulation.isTotalInterestChanged());
        assertEquals(BigDecimal.valueOf(45657.56), secondSimulation.getOutstandingBalance());
        assertEquals(BigDecimal.valueOf(709.56), secondSimulation.getTotalNextMonthlyPayment());
        assertEquals(BigDecimal.valueOf(709.55), secondSimulation.getTotalSecondMonthlyPayment());
        assertEquals(BigDecimal.valueOf(0), secondSimulation.getTotalMonthlyPaymentReduction());
        assertEquals(44, secondSimulation.getTotalTermReduction());

        assertEquals(2, secondSimulation.getOutputLoanDataList().size());
        assertEquals("3R", secondSimulation.getOutputLoanDataList().get(0).getLoanScheme());
        assertEquals(7, secondSimulation.getOutputLoanDataList().get(0).getApplicationSequenceNumber());
        assertEquals(BigDecimal.valueOf(3000), secondSimulation.getOutputLoanDataList().get(0).getLoanOverpaymentAmount());
        assertEquals(BigDecimal.valueOf(3000), secondSimulation.getOutputLoanDataList().get(0).getLoanTotalPaymentAmount());
        assertEquals(BigDecimal.valueOf(0), secondSimulation.getOutputLoanDataList().get(0).getLoanERC());
        assertEquals(BigDecimal.valueOf(636.67), secondSimulation.getOutputLoanDataList().get(0).getCurrentMonthlyPayment());
        assertEquals(BigDecimal.valueOf(636.67), secondSimulation.getOutputLoanDataList().get(0).getSimulationMonthlyPayment());
        assertEquals("02/11/2029", secondSimulation.getOutputLoanDataList().get(0).getCurrentMaturityDate());
        assertEquals("02/06/2029", secondSimulation.getOutputLoanDataList().get(0).getSimulationMaturityDate());
        assertTrue(secondSimulation.getOutputLoanDataList().get(0).getNewMortgageTerm().contains("year"));
        assertTrue(secondSimulation.getOutputLoanDataList().get(0).getNewMortgageTerm().contains("month"));
        assertEquals("0 years, 5 months", secondSimulation.getOutputLoanDataList().get(0).getDiffMortgageTerm());
        assertTrue(secondSimulation.getOutputLoanDataList().get(0).isMortgageTermChanged());
        assertEquals(BigDecimal.valueOf(0), secondSimulation.getOutputLoanDataList().get(0).getDiffMonthlyPayment());
        assertFalse(secondSimulation.getOutputLoanDataList().get(0).isMonthlyPaymentChanged());
        assertEquals(BigDecimal.valueOf(2743.63), secondSimulation.getOutputLoanDataList().get(0).getLoanInterestBeforeSimulation());
        assertEquals(BigDecimal.valueOf(2390.36), secondSimulation.getOutputLoanDataList().get(0).getLoanInterestAfterSimulation());
        assertEquals(BigDecimal.valueOf(353.27), secondSimulation.getOutputLoanDataList().get(0).getDiffLoanInterestSimulation());
        assertTrue(secondSimulation.getOutputLoanDataList().get(0).isLoanInterestChanged());
        assertEquals(BigDecimal.valueOf(636.67), secondSimulation.getOutputLoanDataList().get(0).getFirstPaymentAfterOverpayment());
        assertEquals(BigDecimal.valueOf(636.67), secondSimulation.getOutputLoanDataList().get(0).getSecondPaymentAfterOverpayment());

        assertEquals("3R", secondSimulation.getOutputLoanDataList().get(1).getLoanScheme());
        assertEquals(8, secondSimulation.getOutputLoanDataList().get(1).getApplicationSequenceNumber());
        assertEquals(BigDecimal.valueOf(2986.66), secondSimulation.getOutputLoanDataList().get(1).getLoanOverpaymentAmount());
        assertEquals(BigDecimal.valueOf(3000), secondSimulation.getOutputLoanDataList().get(1).getLoanTotalPaymentAmount());
        assertEquals(BigDecimal.valueOf(13.34), secondSimulation.getOutputLoanDataList().get(1).getLoanERC());
        assertEquals(BigDecimal.valueOf(72.89), secondSimulation.getOutputLoanDataList().get(1).getCurrentMonthlyPayment());
        assertEquals(BigDecimal.valueOf(72.89), secondSimulation.getOutputLoanDataList().get(1).getSimulationMonthlyPayment());
        assertEquals("02/12/2029", secondSimulation.getOutputLoanDataList().get(1).getCurrentMaturityDate());
        assertEquals("02/04/2026", secondSimulation.getOutputLoanDataList().get(1).getSimulationMaturityDate());
        assertTrue(secondSimulation.getOutputLoanDataList().get(1).getNewMortgageTerm().contains("year"));
        assertTrue(secondSimulation.getOutputLoanDataList().get(1).getNewMortgageTerm().contains("month"));
        assertEquals("3 years, 8 months", secondSimulation.getOutputLoanDataList().get(1).getDiffMortgageTerm());
        assertTrue(secondSimulation.getOutputLoanDataList().get(1).isMortgageTermChanged());
        assertEquals(BigDecimal.valueOf(0), secondSimulation.getOutputLoanDataList().get(1).getDiffMonthlyPayment());
        assertFalse(secondSimulation.getOutputLoanDataList().get(1).isMonthlyPaymentChanged());
        assertEquals(BigDecimal.valueOf(322.44), secondSimulation.getOutputLoanDataList().get(1).getLoanInterestBeforeSimulation());
        assertEquals(BigDecimal.valueOf(62.51), secondSimulation.getOutputLoanDataList().get(1).getLoanInterestAfterSimulation());
        assertEquals(BigDecimal.valueOf(259.93), secondSimulation.getOutputLoanDataList().get(1).getDiffLoanInterestSimulation());
        assertTrue(secondSimulation.getOutputLoanDataList().get(1).isLoanInterestChanged());
        assertEquals(BigDecimal.valueOf(72.89), secondSimulation.getOutputLoanDataList().get(1).getFirstPaymentAfterOverpayment());
        assertEquals(BigDecimal.valueOf(72.88), secondSimulation.getOutputLoanDataList().get(1).getSecondPaymentAfterOverpayment());

    }

}