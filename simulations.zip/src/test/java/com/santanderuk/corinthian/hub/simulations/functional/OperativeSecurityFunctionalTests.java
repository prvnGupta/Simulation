package com.santanderuk.corinthian.hub.simulations.functional;

import com.jayway.restassured.response.Header;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;

import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

@ActiveProfiles("operativeSec")
public class OperativeSecurityFunctionalTests extends FunctionalTest {

    Header header;

    String simulationEndpoint;

    @BeforeEach
    public void setup() {
        simulationEndpoint = String.format("http://localhost:%s/simulations/one-off/30000665/simulate", serverPort);

    }

    @Test
    public void operativeSecurityOK() {

        header = new Header("authorization", jwtAuth);
        stubGetRegionHeartbeat();
        stubGetAnmfCustomerInfo();
        stubAccountServiceOk();
        stubAnmf();

        given().
                header(header).
                header("Accept", MediaType.APPLICATION_JSON_VALUE).
                header("Content-Type", MediaType.APPLICATION_JSON_VALUE).
                body(readFileContents("simulation/valid-simulation-request-include-or-add.json")).
                when().
                put(simulationEndpoint).
                then().
                statusCode(200).and()
                .body("info.status", equalTo("ok"));
    }

    @Test
    public void operativeSecurityANMFDown() {
        header = new Header("authorization", jwtWithNoCustomer);
        stubGetRegionHeartbeat();
        stubGetAnmfCustomerInfoDown();
        stubAnmf();

        given().
                header(header).
                header("Accept", MediaType.APPLICATION_JSON_VALUE).
                header("Content-Type", MediaType.APPLICATION_JSON_VALUE).
                body(readFileContents("simulation/valid-simulation-request-include-or-add.json")).
                when().
                put(simulationEndpoint).
                then().
                statusCode(401).and()
                .body("info.code", equalTo("SECURITY_KO"),
                        "info.message", equalTo("Mortgage does not belong to customer"));
    }

    @Test
    public void operativeSecurityWrongCID() {
        header = new Header("authorization", jwtWithNoCustomer);
        stubGetRegionHeartbeat();
        stubGetAnmfCustomerInfo();
        stubAnmf();

        given().
                header(header).
                header("Accept", MediaType.APPLICATION_JSON_VALUE).
                header("Content-Type", MediaType.APPLICATION_JSON_VALUE).
                body(readFileContents("simulation/valid-simulation-request-include-or-add.json")).
                when().
                put(simulationEndpoint).
                then().
                statusCode(401).and()
                .body("info.code", equalTo("SECURITY_KO"),
                        "info.message", equalTo("Mortgage does not belong to customer"));
    }

}
