package com.santanderuk.corinthian.hub.simulations.api.simulation.services;

import com.santanderuk.corinthian.hub.simulations.TestDataCreator;
import com.santanderuk.corinthian.hub.simulations.api.simulation.model.DataResponse;
import com.santanderuk.corinthian.hub.simulations.api.simulation.model.SimulationListInput;
import com.santanderuk.corinthian.hub.simulations.config.AnmfConfig;
import com.santanderuk.corinthian.services.commons.anmfclient.SimulationClient;
import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.ANMFSimulationRequest;
import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.ANMFSimulationResponse;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.HeartBeatClient;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.util.List;

import static com.santanderuk.corinthian.hub.simulations.TestDataCreator.generateAnmfSimulationDefaultResponse;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;

@ExtendWith(MockitoExtension.class)
class SimulationServiceTest {

    private final String jwt = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImlvYyIsImlzYyIsImx5bngiXSwibmJmIjoxNTA3ODE2NDU4LCJleHAiOjE1MDc4MjAwNTgsImlhdCI6MTUwNzgxNjQ1OCwianRpIjoiNDNjNDM2YjQtNmEyOS00ZWQ1LWE0ZWItYTM2MWQwYTU4ZjhmIiwibWlzIjoiYTpCNDY1Nzg4MTczQ0UwNzAwMTA1MEQ4Qjg6RjU1NDowMDE1OmViYW5raW5nIn0.LFea7Gcr61387fm-ai4hBRS-dnfoIjujrBMmAL9WezDVve2ov5VzfYMYLGuPmLF7FROHQ9sTUjlpgiDNuvgw-oZlW4yaFf6OTQOgXVn6OZPLLvxRL8U2X65-JXvZpIV6n3vLA2lIsManE0jsjt7C2UvMiQsB0veeCbbwPSZRU1CJbjnuWF7KWhZy2zAqKq47rVOOosHveWAEuu0rxGS-aMN3xdYwbKOlIEEZen9Jgqr_YEE4FHlCovFmZXpp5dM_AKCxQaHUm_EhA3nd2tnRnemqSMybq04BPZIA7iSTiXc-VXKfCQSUNurdvxI9tol2_tPZdeWpKfY-KlA8ngvJ8g";
    private SimulationService simulationService;
    @Mock
    private SimulationRequestMapper simulationRequestMapper;

    @Mock
    private AnmfConfig anmfConfig;
    @Mock
    private HeartBeatClient heartBeatClient;
    @Mock
    private SimulationClient simulationClient;
    @Mock
    private SimulationsResponseMapper simulationsResponseMapper;

    @BeforeEach
    void setUp() {
        simulationService = new SimulationService(simulationRequestMapper, anmfConfig, heartBeatClient, simulationClient, simulationsResponseMapper);
    }


    @Test
    void testGeneralExceptionFromRequestMapper() throws IOException, GeneralException {
        SimulationListInput simulationListInput = TestDataCreator.generateDefaultSimulationControllerRequest();
        Mockito.when(simulationRequestMapper.mapInput(anyInt(), any(), any(), anyString())).thenThrow(GeneralException.class);
        assertThrows(GeneralException.class, () -> simulationService.getSimulations(123456789, simulationListInput, jwt));
    }

    @Test
    void testHappyPath() throws IOException, GeneralException {

        List<ANMFSimulationRequest> simulationRequestList = TestDataCreator.generateSimulationInputMapperDefaultResponse();
        SimulationListInput simulationListInput = TestDataCreator.generateDefaultSimulationControllerRequest();
        List<ANMFSimulationResponse> anmfSimulationResponseList = List.of(generateAnmfSimulationDefaultResponse(), generateAnmfSimulationDefaultResponse());
        Mockito.when(simulationRequestMapper.mapInput(anyInt(), any(), any(), anyString())).thenReturn(simulationRequestList);
        Mockito.when(anmfConfig.getSimulationUrl()).thenReturn("http://dummy.com/sanuk/internal/mortgage-payments/v3/overpayment/simulation");
        Mockito.when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);
        Mockito.when(simulationClient.simulate(anyString(), any(), any())).thenReturn(TestDataCreator.generateAnmfSimulationDefaultResponse());
        Mockito.when(simulationsResponseMapper.createResponse(any(), any())).thenReturn(TestDataCreator.generateDefaultSimulationServiceResponse());
        DataResponse dataResponse = simulationService.getSimulations(123456789, simulationListInput, jwt);

        assertEquals(2, dataResponse.getSimulationResponseList().size());
    }
}
