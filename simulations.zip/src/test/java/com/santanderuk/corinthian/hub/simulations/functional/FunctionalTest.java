package com.santanderuk.corinthian.hub.simulations.functional;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.jayway.restassured.RestAssured;
import com.santanderuk.corinthian.hub.simulations.SimulationsApplication;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.support.TestPropertySourceUtils;
import org.springframework.util.SocketUtils;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.jayway.restassured.config.JsonConfig.jsonConfig;
import static com.jayway.restassured.config.RestAssuredConfig.newConfig;
import static com.jayway.restassured.path.json.config.JsonPathConfig.NumberReturnType.BIG_DECIMAL;

@ContextConfiguration(initializers = FunctionalTest.RandomPortInitailizer.class)
@ExtendWith(MockitoExtension.class)
@SpringBootTest(classes = SimulationsApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public abstract class FunctionalTest {

    public WireMockServer heartbeatWireMock;
    public WireMockServer anmfWireMock;
    protected String jwtAuth = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImlvYyIsImlzYyIsImx5bngiXSwibmJmIjoxNTA3ODE2NDU4LCJleHAiOjE1MDc4MjAwNTgsImlhdCI6MTUwNzgxNjQ1OCwianRpIjoiNDNjNDM2YjQtNmEyOS00ZWQ1LWE0ZWItYTM2MWQwYTU4ZjhmIiwibWlzIjoiYTpCNDY1Nzg4MTczQ0UwNzAwMTA1MEQ4Qjg6RjU1NDowMDE1OmViYW5raW5nIn0.LFea7Gcr61387fm-ai4hBRS-dnfoIjujrBMmAL9WezDVve2ov5VzfYMYLGuPmLF7FROHQ9sTUjlpgiDNuvgw-oZlW4yaFf6OTQOgXVn6OZPLLvxRL8U2X65-JXvZpIV6n3vLA2lIsManE0jsjt7C2UvMiQsB0veeCbbwPSZRU1CJbjnuWF7KWhZy2zAqKq47rVOOosHveWAEuu0rxGS-aMN3xdYwbKOlIEEZen9Jgqr_YEE4FHlCovFmZXpp5dM_AKCxQaHUm_EhA3nd2tnRnemqSMybq04BPZIA7iSTiXc-VXKfCQSUNurdvxI9tol2_tPZdeWpKfY-KlA8ngvJ8g";

    @LocalServerPort
    protected String serverPort;

    @Value("${heartbeat.endpoints.port}")
    protected int heartBeatPort;

    @Value("${anmf.endpoints.port}")
    protected int anmfPort;

    String jwtWithNoCustomer = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImx5bngiLCJpb2MiLCJpc2MiLCJsYWMiXSwibmJmIjoxNTE5MjA3MjgzLCJleHAiOjE1MTkyMTA4ODMsImlhdCI6MTUxOTIwNzI4MywianRpIjoiMjIwNDEyOGYtY2ZlMi00ZWMxLTkyMjItZmQzMmVmNDQxMjE0In0.p2WEO3nyKZaeMs4VjVOI5FDvlqzjsFe_iO7RygccU4xLSk8teIW0FuNL50_JZAFL0S5jZEIBCAUlYyb3Xz-NNUoRC0SWJC0sSfeSuapSBTdBgw8JFcXyn6wTUm-fpo1gyUtFq4CcjqmQt5RMzR6sp0WoVileuHDyntWYYN9u4hBA2iln5seLj1PDcMH4YHNzgTedoBOwMrWknjTrVgVfz63wiOlPDlgzQHtlxYI3vvkXrL99J_8C7sfip2SYM8tn_YTyCte176MQPuh0GOwS8ZfMg_nIJyF3gXrJQZhNrQjCzr1zXEESY0Ly19EznHyp7rHpZDWhkUGs6J18PkYNTA";

    protected static String readFileContents(String filename) {
        InputStream resource;
        String fixtureContents = "";
        try {
            resource = new ClassPathResource(String.format("/fixtures/%s", filename)).getInputStream();
            fixtureContents = IOUtils.toString(resource, Charset.defaultCharset());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return fixtureContents;
    }

    @BeforeEach
    public void setUp() {

        RestAssured.config = newConfig().jsonConfig(jsonConfig().numberReturnType(BIG_DECIMAL));

        heartbeatWireMock = new WireMockServer(heartBeatPort);
        heartbeatWireMock.start();
        anmfWireMock = new WireMockServer(anmfPort);
        anmfWireMock.start();

    }

    @AfterEach
    public void tearDown() {
        heartbeatWireMock.stop();
        anmfWireMock.stop();
    }

    protected void stubGetRegionHeartbeat() {

        heartbeatWireMock.stubFor(get(urlPathEqualTo("/heartbeat/get-region"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withHeader("Accept", "application/json")
                        .withBody(readFileContents("heartbeat-response.json"))));
    }

    protected void stubAnmf() {

        anmfWireMock.stubFor(post(urlPathEqualTo("/sanuk/internal/mortgage-payments/v3/overpayment/simulation"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withHeader("Accept", "application/json")
                        .withBody(readFileContents("anmf-simulation-response.json"))));
    }


    protected void stubAnmfIncludeCharge() {
        anmfWireMock.stubFor(post(urlPathEqualTo("/sanuk/internal/mortgage-payments/v3/overpayment/simulation"))
                .withRequestBody(containing("\"i_erc_coll_opt\":\"I\""))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withHeader("Accept", "application/json")
                        .withBody(readFileContents("simulation/anmf-include-charge-response.json"))));
    }
    protected void stubAnmfIncludeChargeReduceTerm12143533() {
        anmfWireMock.stubFor(post(urlPathEqualTo("/sanuk/internal/mortgage-payments/v3/overpayment/simulation"))
                .withRequestBody(containing("\"i_erc_coll_opt\":\"I\""))
                .withRequestBody(containing("\"i_change_type\":\"T\""))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withHeader("Accept", "application/json")
                        .withBody(readFileContents("single-loan/includeTerm.json"))));
    }
    protected void stubAnmfIncludeChargeReduceMonthlyPayment12143533() {
        anmfWireMock.stubFor(post(urlPathEqualTo("/sanuk/internal/mortgage-payments/v3/overpayment/simulation"))
                .withRequestBody(containing("\"i_erc_coll_opt\":\"I\""))
                .withRequestBody(containing("\"i_change_type\":\"M\""))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withHeader("Accept", "application/json")
                        .withBody(readFileContents("single-loan/includeMar.json"))));
    }
    protected void stubAnmfAddChargeReduceTerm12143533() {
        anmfWireMock.stubFor(post(urlPathEqualTo("/sanuk/internal/mortgage-payments/v3/overpayment/simulation"))
                .withRequestBody(containing("\"i_erc_coll_opt\":\"O\""))
                .withRequestBody(containing("\"i_change_type\":\"T\""))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withHeader("Accept", "application/json")
                        .withBody(readFileContents("single-loan/addTerm.json"))));
    }
    protected void stubAnmfAddChargeReduceMonthlyPayment12143533() {
        anmfWireMock.stubFor(post(urlPathEqualTo("/sanuk/internal/mortgage-payments/v3/overpayment/simulation"))
                .withRequestBody(containing("\"i_erc_coll_opt\":\"O\""))
                .withRequestBody(containing("\"i_change_type\":\"M\""))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withHeader("Accept", "application/json")
                        .withBody(readFileContents("single-loan/addMar.json"))));
    }


    protected void stubAnmfAddChargeReduceMonthlyPaymentSingleLoanInterestOnly() {
        anmfWireMock.stubFor(post(urlPathEqualTo("/sanuk/internal/mortgage-payments/v3/overpayment/simulation"))
                .withRequestBody(containing("\"i_erc_coll_opt\":\"O\""))
                .withRequestBody(containing("\"i_change_type\":\"M\""))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withHeader("Accept", "application/json")
                        .withBody(readFileContents("single-loan-interest-only/addMar.json"))));
    }

    protected void stubAnmfIncludeChargeReduceMonthlyPaymentSingleLoanInterestOnly() {
        anmfWireMock.stubFor(post(urlPathEqualTo("/sanuk/internal/mortgage-payments/v3/overpayment/simulation"))
                .withRequestBody(containing("\"i_erc_coll_opt\":\"I\""))
                .withRequestBody(containing("\"i_change_type\":\"M\""))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withHeader("Accept", "application/json")
                        .withBody(readFileContents("single-loan-interest-only/includeMar.json"))));
    }

    protected void stubAnmfIncludeChargeReduceTermMultiLoanFixedOneLoanOverpaid() {
        anmfWireMock.stubFor(post(urlPathEqualTo("/sanuk/internal/mortgage-payments/v3/overpayment/simulation"))
                .withRequestBody(containing("\"i_erc_coll_opt\":\"I\""))
                .withRequestBody(containing("\"i_ln_ovp_amount\":2000,\"i_change_type\":\"T\""))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withHeader("Accept", "application/json")
                        .withBody(readFileContents("multi-loan-3-fixed-one-loan-overpaid/includeTerm.json"))));
    }

    protected void stubAnmfIncludeChargeReduceMonthlyPaymentMultiLoanFixedOneLoanOverpaid() {
        anmfWireMock.stubFor(post(urlPathEqualTo("/sanuk/internal/mortgage-payments/v3/overpayment/simulation"))
                .withRequestBody(containing("\"i_erc_coll_opt\":\"I\""))
                .withRequestBody(containing("\"i_ln_ovp_amount\":2000,\"i_change_type\":\"M\""))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withHeader("Accept", "application/json")
                        .withBody(readFileContents("multi-loan-3-fixed-one-loan-overpaid/includeMar.json"))));
    }

    protected void stubAnmfIncludeChargeReduceTermMultiLoanFixedAllLoansOverpaid() {
        anmfWireMock.stubFor(post(urlPathEqualTo("/sanuk/internal/mortgage-payments/v3/overpayment/simulation"))
                .withRequestBody(containing("\"i_erc_coll_opt\":\"I\""))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withHeader("Accept", "application/json")
                        .withBody(readFileContents("multi-loan-3-fixed-all-loans-overpaid/includeTerm.json"))));
    }

    protected void stubAnmfAddChargeReduceTermMultiLoanFixedAllLoansOverpaid() {
        anmfWireMock.stubFor(post(urlPathEqualTo("/sanuk/internal/mortgage-payments/v3/overpayment/simulation"))
                .withRequestBody(containing("\"i_erc_coll_opt\":\"O\""))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withHeader("Accept", "application/json")
                        .withBody(readFileContents("multi-loan-3-fixed-all-loans-overpaid/addTerm.json"))));
    }


    protected void stubAnmfIncludeChargeReduceTermMultiLoanCombinedAllowance() {
        anmfWireMock.stubFor(post(urlPathEqualTo("/sanuk/internal/mortgage-payments/v3/overpayment/simulation"))
                .withRequestBody(containing("\"i_erc_coll_opt\":\"I\""))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withHeader("Accept", "application/json")
                        .withBody(readFileContents("multi-loan-2-loans-combined-allowance/includeTerm.json"))));
    }

    protected void stubAnmfAddChargeReduceTermMultiLoanCombinedAllowance() {
        anmfWireMock.stubFor(post(urlPathEqualTo("/sanuk/internal/mortgage-payments/v3/overpayment/simulation"))
                .withRequestBody(containing("\"i_erc_coll_opt\":\"O\""))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withHeader("Accept", "application/json")
                        .withBody(readFileContents("multi-loan-2-loans-combined-allowance/addTerm.json"))));
    }

    protected void stubAnmfAddCharge() {
        anmfWireMock.stubFor(post(urlPathEqualTo("/sanuk/internal/mortgage-payments/v3/overpayment/simulation"))
                .withRequestBody(containing("\"i_erc_coll_opt\":\"O\""))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withHeader("Accept", "application/json")
                        .withBody(readFileContents("simulation/anmf-add-charge-response.json"))));
    }


    protected void stubAnmfReduceTerm() {
        anmfWireMock.stubFor(post(urlPathEqualTo("/sanuk/internal/mortgage-payments/v3/overpayment/simulation"))
                .withRequestBody(containing("\"i_change_type\":\"T\""))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withHeader("Accept", "application/json")
                        .withBody(readFileContents("simulation/anmf-reduce-term-response.json"))));
    }


    protected void stubAnmfReduceMonthlyPayments() {
        anmfWireMock.stubFor(post(urlPathEqualTo("/sanuk/internal/mortgage-payments/v3/overpayment/simulation"))
                .withRequestBody(containing("\"i_change_type\":\"M\""))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withHeader("Accept", "application/json")
                        .withBody(readFileContents("simulation/anmf-reduce-monthly-payment-response.json"))));
    }

    protected void stubAccountServiceOk() {
        anmfWireMock.stubFor(get(urlPathEqualTo("/sanuk/internal/mortgage-account-details/accounts/30000665"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withHeader("Accept", "application/json")
                        .withBody(readFileContents("account-details/anmf-account-details-default-response.json"))));
    }


    protected void stubGetAnmfCustomerInfo() {

        anmfWireMock.stubFor(get(urlPathEqualTo("/sanuk/internal/mortgage-customer-details/accounts/30000665/customers"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("mortgage-customer-details-default-response.json"))));
    }

    protected void stubGetAnmfCustomerInfoDown() {

        anmfWireMock.stubFor(get(urlPathEqualTo("/sanuk/internal/mortgage-customer-details/accounts/30000665/customers"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withStatus(500)
                )
        );
    }

    public static class RandomPortInitailizer
            implements ApplicationContextInitializer<ConfigurableApplicationContext> {

        @Override
        public void initialize(ConfigurableApplicationContext applicationContext) {
            int randomHeartBeatPort = SocketUtils.findAvailableTcpPort();
            int randomAnmfPort = SocketUtils.findAvailableTcpPort();

            String heartBeatRegionUrl = String.format("http://localhost:%d/heartbeat/get-region", randomHeartBeatPort);
            String anmfARegionUrl = String.format("http://localhost:%d/sanuk/internal/mortgage-payments/v3/overpayment/simulation", randomAnmfPort);
            String anmfGetCustomerInfoUrl = String.format("http://localhost:%d/sanuk/internal/mortgage-customer-details/accounts/{account}/customers", randomAnmfPort);
            String anmfAccountDetailsUrl = String.format("http://localhost:%d/sanuk/internal/mortgage-account-details/accounts/{account}", randomAnmfPort);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext, "anmf.services.customerservice=" + anmfGetCustomerInfoUrl);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext, "anmf.services.account-service=" + anmfAccountDetailsUrl);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "heartbeat.get-region=" + heartBeatRegionUrl);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "heartbeat.endpoints.port=" + randomHeartBeatPort);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "anmf.services.simulation=" + anmfARegionUrl);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "anmf.endpoints.port=" + randomAnmfPort);

        }

    }


}
