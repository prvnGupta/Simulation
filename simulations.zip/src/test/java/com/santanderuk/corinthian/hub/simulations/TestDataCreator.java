package com.santanderuk.corinthian.hub.simulations;

import com.santanderuk.corinthian.hub.simulations.api.simulation.model.DataResponse;
import com.santanderuk.corinthian.hub.simulations.api.simulation.model.SimulationListInput;
import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.ANMFSimulationRequest;
import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.ANMFSimulationResponse;
import com.santanderuk.corinthian.services.commons.model.BdpCustomer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class TestDataCreator {

    public static SimulationListInput generateDefaultSimulationControllerRequest() throws IOException {
        return FixtureReader.get("simulation/simulation-list-input.json", SimulationListInput.class);
    }

    public static ANMFSimulationResponse generateAnmfSimulationAddChargeResponse() throws IOException {
        return FixtureReader.get("simulation/anmf-add-charge-response.json", ANMFSimulationResponse.class);
    }

    public static ANMFSimulationResponse generateAnmfSimulationIncludeChargeResponse() throws IOException {
        return FixtureReader.get("simulation/anmf-include-charge-response.json", ANMFSimulationResponse.class);
    }

    public static ANMFSimulationResponse generateAnmfSimulationDefaultResponse() throws IOException {
        return FixtureReader.get("anmf-simulation-response.json", ANMFSimulationResponse.class);
    }

    public static List<ANMFSimulationRequest> generateSimulationInputMapperDefaultResponse() throws IOException {
        List<ANMFSimulationRequest> simulationRequestList = new ArrayList<>(2);
        ANMFSimulationRequest simulationRequest1 = createDefaultAnmfSimulationRequest();
        simulationRequestList.add(simulationRequest1);

        ANMFSimulationRequest simulationRequest2 = createDefaultAnmfSimulationRequest();
        simulationRequestList.add(simulationRequest2);
        return simulationRequestList;
    }

    public static BdpCustomer createDefaultBdpCustomer() {
        BdpCustomer bdpCustomer = new BdpCustomer();
        bdpCustomer.setCustomerType("F");
        bdpCustomer.setCustomerNumber(123456789);
        return bdpCustomer;
    }

    private static ANMFSimulationRequest createDefaultAnmfSimulationRequest() throws IOException {
        return FixtureReader.get("simulation/anmf-simulation-request.json", ANMFSimulationRequest.class);

    }


    public static DataResponse generateDefaultSimulationServiceResponse() throws IOException {
        return FixtureReader.get("simulation-response-mapper-response.json", DataResponse.class);
    }

    public static List<ANMFSimulationResponse> generateListOfSimulationResponses() throws IOException {
        return List.of(generateAnmfSimulationDefaultResponse(), generateAnmfSimulationIncludeChargeResponse(), generateAnmfSimulationAddChargeResponse());
    }

    public static ANMFSimulationRequest generateAnmfSimulationRequestInclude() throws IOException {
        return FixtureReader.get("simulation/anmf-include-charge-request.json", ANMFSimulationRequest.class);
    }

    public static ANMFSimulationRequest generateAnmfSimulationRequestAdd() throws IOException {
        return FixtureReader.get("simulation/anmf-add-charge-request.json", ANMFSimulationRequest.class);
    }

    public static ANMFSimulationRequest generateAnmfSimulationRequest() throws IOException {
        return FixtureReader.get("anmf-simulation-request.json", ANMFSimulationRequest.class);
    }

    public static List<ANMFSimulationRequest> generateListOfSimulationRequests() throws IOException {
        return List.of(generateAnmfSimulationRequest(), generateAnmfSimulationRequestInclude(), generateAnmfSimulationRequestAdd());
    }

    public static ANMFSimulationRequest generateAnmfSimulationRequestAddMultiLoan() throws IOException {
        return FixtureReader.get("multi-loan-2-loans-combined-allowance/anmfRequestAddTerm.json", ANMFSimulationRequest.class);
    }

    public static ANMFSimulationRequest generateAnmfSimulationRequestIncludeMultiLoan() throws IOException {
        return FixtureReader.get("multi-loan-2-loans-combined-allowance/anmfRequestIncludeTerm.json", ANMFSimulationRequest.class);
    }

    public static List<ANMFSimulationRequest> generateListOfSimulationRequestsMultiLoan() throws IOException {
        return List.of(generateAnmfSimulationRequestAddMultiLoan(), generateAnmfSimulationRequestIncludeMultiLoan());
    }

    public static ANMFSimulationResponse generateAnmfSimulationResponseAddMultiLoan() throws IOException {
        return FixtureReader.get("multi-loan-2-loans-combined-allowance/addTerm.json", ANMFSimulationResponse.class);
    }

    public static ANMFSimulationResponse generateAnmfSimulationResponseIncludeMultiLoan() throws IOException {
        return FixtureReader.get("multi-loan-2-loans-combined-allowance/includeTerm.json", ANMFSimulationResponse.class);
    }

    public static List<ANMFSimulationResponse> generateListOfSimulationResponsesMultiLoan() throws IOException {
        return List.of(generateAnmfSimulationResponseAddMultiLoan(), generateAnmfSimulationResponseIncludeMultiLoan());
    }
}
