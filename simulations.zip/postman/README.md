When importing this collection remember that for the token, environment variables must be created.

Like in the picture below:

![](environment-variables.png)

Also remember to select that enviroment when doing your tests
![](environment-selection.png)
